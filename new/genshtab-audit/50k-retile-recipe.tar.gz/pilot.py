"""Exercise the actual PMTiles writer and verifier with old and newly rendered WebP payloads."""
import hashlib,json,sqlite3,tempfile
from itertools import islice
from pathlib import Path
from pmtiles.tile import zxy_to_tileid,tileid_to_zxy
from archives50 import Old,write_json
from pack50 import Row,write_verify
root=Path.cwd()
old=Old(root)
try:
    rows=[];old_bytes=bytearray()
    new_files=list(islice((root/'tiles/14').glob('*/*.webp'),64))
    for f in new_files:
        z=14;x=int(f.parent.name);y=int(f.stem);raw=f.read_bytes()
        rows.append(Row(zxy_to_tileid(z,x,y),z,x,y,len(raw),-1,hashlib.sha256(raw).digest()))
    with (root/'unchanged-children.xyz').open() as stream:
        for ln in stream:
            z,x,y=map(int,ln.split());tid=zxy_to_tileid(z,x,y)
            if not int(old.index[tid]):continue
            raw=old.data_at(tid);off=len(old_bytes);old_bytes.extend(raw)
            rows.append(Row(tid,z,x,y,len(raw),off,None))
            if len(rows)==len(new_files)+32:break
    assert len(new_files)==64 and len(rows)==len({r.tid for r in rows})==96
    with tempfile.TemporaryDirectory(dir=root) as tmp:
        ret=write_verify(root,rows,bytes(old_bytes),Path(tmp)/'pilot.pmtiles',old.get_metadata(),{}, {})
    write_json(root/'pilot-verification.json',{'new':64,'old':32,'addressed_tiles':ret['tiles'],'bytes':ret['size'],'sha256':ret['sha256']})
    print('Verified 64 rendered and 32 original payloads through the production PMTiles writer and reader.')
finally:
    old.cleanup()
