"""Verify new COG hardlinks and download only historical COGs needed along the update boundary."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

job=Path.cwd()
sources=job/'sources'
sources.mkdir(exist_ok=True)
neighbor_dir=job/'historical-cogs'
neighbor_dir.mkdir(exist_ok=True)
new_dir=job.parent/'rwt-50k-warps-20261122/cogs'
records=json.loads((job/'sources.json').read_bytes())

def valid(path, row):
    if not path.is_file() or path.stat().st_size != row['size']:
        return False
    with path.open('rb') as stream:
        return 'sha256:'+hashlib.file_digest(stream,'sha256').hexdigest()==row['digest']

def get(name, row):
    dest=sources/name
    if row['local'] and (new_dir/name).is_file():
        actual=new_dir/name
        if not dest.exists():
            dest.symlink_to(actual.resolve())
        assert dest.samefile(actual) and valid(dest,row),name
        return
    actual=neighbor_dir/name
    if not valid(actual,row):
        tmp=actual.with_suffix('.partial')
        for attempt in range(4):
            result=subprocess.run(['curl','-4','-fsSL','--retry','4','--retry-all-errors','--connect-timeout','15','--max-time','240','-o',str(tmp),row['url']+'?asset_sha='+row['digest'][7:19]],stdout=subprocess.DEVNULL)
            if result.returncode==0 and valid(tmp,row):
                tmp.replace(actual)
                break
            time.sleep(2**attempt)
        else:
            raise RuntimeError('Could not fetch the published COG with its expected checksum: '+name)
    if not dest.is_symlink():
        dest.symlink_to(actual)
    assert dest.resolve()==actual and dest.stat().st_size==row['size']
with ThreadPoolExecutor(6) as pool:
    futures=[pool.submit(get,n,r) for n,r in sorted(records.items(),key=lambda item:item[1]['local'])]
    for count,f in enumerate(as_completed(futures),1):
        f.result()
        if count%250==0:
            print('Verified',count,'of',len(records),'COGs',flush=True)
info={'verified':len(records),'new':sum(r['local'] for r in records.values()),'source_register_sha256':hashlib.sha256((job/'sources.json').read_bytes()).hexdigest()}
tmp=job/'sources-ready.tmp';tmp.write_text(json.dumps(info));tmp.replace(job/'sources-ready.json')
print(info,flush=True)
