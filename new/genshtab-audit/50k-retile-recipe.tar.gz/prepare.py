"""Plan the 1:50k retile from the published sheet and validity-mask footprints."""
import csv
import gzip
import hashlib
import json
from pathlib import Path
import mercantile
from shapely.geometry import shape, box, mapping
from shapely.ops import unary_union

job=Path(__file__).resolve().parent
audit=job.parents[2]
metadata=audit/'staging/rwt-50k-metadata-20261122/final'
publish=audit/'staging/rwt-50k-publish-20261122'
def read(p):return json.loads(p.read_bytes())
def save(name,obj):(job/name).write_text(json.dumps(obj,separators=(',',':'))+'\n')
def lines(name,items):(job/name).write_text(''.join(x+'\n' for x in sorted(items)))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
verify=read(audit/'50k-release-verification.json')
raw=metadata/'bounds.geojson'
boundsha=read(metadata/'verification.json')['bounds_sha256']
assert sha(raw)==boundsha==verify['georeferenced_catalogue']['assets']['bounds.geojson']['sha256']
features={f['properties']['id']:f for f in read(raw)['features']}
with gzip.open(publish/'all-listed-assets.csv.gz','rt') as stream:
    assets={r['name'][:-4]:r for r in csv.DictReader(stream) if r['kind']=='georef' and r['name'].endswith('.tif')}
with (audit/'50k-staged-cogs.csv').open() as stream:
    new={r['scan_id']:r for r in csv.DictReader(stream)}
assert len(new)==4387 and set(assets)==set(features) and len(features)==14252
changed=verify['georeferenced_catalogue']['historical_footprint_corrections']
assert len(changed)==10 and set(changed).isdisjoint(new)
zoom=read(job/'old-mosaic.json')['header']['max_zoom']
assert zoom==14 and sha(job/'old-mosaic.json')=='434403afc777eddd905d78fa6db0477d7452d99e4a7f52bfdb321c083ce028dc'
def tiles(ext):return ((t.x,t.y) for t in mercantile.tiles(*ext,[zoom]))
geoms={k:shape(f['geometry']) for k,f in features.items()}
update=set(new).union(changed)
extents={k:g.bounds for k,g in geoms.items()}
for k in changed:
    former=shape(json.loads(features[k]['properties']['source_graticule_wgs84']))
    extents[k]=unary_union([former,geoms[k]]).bounds
base=set()
for k in update:base.update(tiles(extents[k]))
required={k for k,e in extents.items() if any(t in base for t in tiles(e))}
assert update<=required
record={}
for k in sorted(required):
    a=assets[k]
    if k in new:assert a['sha256']==new[k]['tiff_sha256']
    digest=features[k]['properties'].get('digest')
    assert not digest or digest.removeprefix('sha256:')==a['sha256'],k
    record[k+'.tif']=dict(size=int(a['size']),digest='sha256:'+a['sha256'],url=a['url'],local=k in new)
save('sources.json',record)
save('affected-bounds.geojson',{'type':'FeatureCollection','features':[{'type':'Feature','properties':{'id':k},'geometry':mapping(box(*extents[k]))} for k in sorted(required)]})
lines('required.txt',[n+'.tif' for n in required]);lines('retile-sheets.txt',[n+'.tif' for n in update])
centres={}
for f in read(audit/'coverage/50k.geojson')['features']:
    p=f['properties']
    if p['coverage_status']!='published_addition':continue
    sid=p['scan_id'];geom=geoms[sid].intersection(shape(f['geometry']));point=geom.centroid
    if not geom.contains(point):point=geom.representative_point()
    centres.setdefault(sid,{})[p['id']]=[point.x,point.y]
assert set(centres)==set(new) and sum(map(len,centres.values()))==4470
save('centres-input.json',centres)
save('restored-centres.json',{s:list(geoms[s].representative_point().coords[0]) for s in changed})
parent=base
with (job/'affected-base.xyz').open('w') as f:
    for x,y in sorted(base):print(zoom,x,y,file=f)
levels={zoom:len(base)};siblings={}
with (job/'unchanged-children.xyz').open('w') as f:
    for z in range(zoom,0,-1):
        ancestors={(x//2,y//2) for x,y in parent}
        complement={(2*x+i,2*y+j) for x,y in ancestors for i in (0,1) for j in (0,1)}-parent
        for x,y in sorted(complement):print(z,x,y,file=f)
        levels[z-1]=len(ancestors);siblings[z]=len(complement);parent=ancestors
plan=dict(new=len(new),restored=sorted(changed),neighboring_cogs=len(required-update),required_cogs=len(required),base_zoom=zoom,levels=levels,unchanged_children=siblings,neighbors_bytes=sum(r['size'] for r in record.values() if not r['local']),released_bounds_sha256=boundsha)
save('plan.json',plan)
print(json.dumps(plan))
