#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONPATH="$PWD:/usr/lib/python3/dist-packages"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
while [ ! -f old-dirs/ready.json ]; do sleep 20; done
python3 -u check_old_routing.py > stripe-check.log 2>&1
while [ ! -s patch-ready.json ] || [ ! -s render-cog-samples-320.json ]; do sleep 30; done
python3 -u pack50.py
