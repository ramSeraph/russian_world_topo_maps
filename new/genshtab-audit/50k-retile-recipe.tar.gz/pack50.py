"""Write and exhaustively compare one immutable dated PMTiles shard at a time."""
import argparse
from collections import Counter, defaultdict, namedtuple
import fcntl
import gzip
import hashlib
import io
import itertools
import json
import math
import mmap
import os
import shutil
import sqlite3
import tempfile
import time
from pathlib import Path

import mercantile
from PIL import Image
from pmtiles import tile as pm_tile
from pmtiles import writer as pm_writer
from pmtiles.reader import Reader
from pmtiles.tile import deserialize_header,tileid_to_zxy,zxy_to_tileid,TileType,Compression
from pmtiles_mosaic.partition_common import SLICE_HEADER_EXPORT_KEYS,HEADER_EXPORT_KEYS,convert_header
from archives50 import records,digest,write_json,walk_entries
from full_old50 import WORK,full
from patchindex50 import build,boundaries,groupof

Row=namedtuple('Row','tid z x y n offset sha')
LIMIT=2**31-4_000_000
class CanonicalGzip:
    decompress=staticmethod(gzip.decompress)
    @staticmethod
    def compress(data):return gzip.compress(data,mtime=0)
# PMTiles Python 3.12's gzip default embeds its wallclock, even in an otherwise-identical archive.
pm_tile.gzip=CanonicalGzip;pm_writer.gzip=CanonicalGzip

def attr_check(meta):
    attr=meta['attribution'].lower()
    assert meta['format']=='webp'
    for s in ('vlasenko.net','topographic-maps','genshtab-100k-50k-europe-asia','redatlasbook.com','permission','non-commercial'):assert s in attr,s

def geometry(z,x0,y0,x1,y1):
    west,south,east,north=mercantile.bounds(x0,y1,z)[0],mercantile.bounds(x0,y1,z)[1],mercantile.bounds(x1,y0,z)[2],mercantile.bounds(x1,y0,z)[3]
    return {k:int(v*1e7) for k,v in zip(('min_lon_e7','min_lat_e7','max_lon_e7','max_lat_e7'),(west,south,east,north))}

def header(zmin,zmax,ext):
    h={'tile_type':TileType.WEBP,'tile_compression':Compression.NONE,'min_zoom':zmin,'max_zoom':zmax,**ext}
    h.update(center_zoom=(zmin+zmax)//2,center_lon_e7=int((h['min_lon_e7']+h['max_lon_e7'])/2),center_lat_e7=int((h['min_lat_e7']+h['max_lat_e7'])/2))
    return h

def bounds_of(rows):
    zmin=min(r.z for r in rows);zmax=max(r.z for r in rows)
    upper=[r for r in rows if r.z==zmax]
    hi=geometry(zmax,min(r.x for r in upper),min(r.y for r in upper),max(r.x for r in upper),max(r.y for r in upper))
    # Cover every tile, including children whose own parent lies beyond a sparse min-zoom set.
    lo=geometry(zmin,min(r.x>>(r.z-zmin) for r in rows),min(r.y>>(r.z-zmin) for r in rows),max(r.x>>(r.z-zmin) for r in rows),max(r.y>>(r.z-zmin) for r in rows))
    return header(zmin,zmax,hi),convert_header(header(zmin,zmax,lo),SLICE_HEADER_EXPORT_KEYS)

def pixel(lon,lat,z=14):
    t=mercantile.tile(lon,lat,z)
    px=int(((lon+180)/360*(1<<z)-t.x)*256)
    py=int(((1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*(1<<z)-t.y)*256)
    return [z,t.x,t.y],[max(0,min(255,px)),max(0,min(255,py))]

def probe_plan(root,edges):
    allp=json.loads((root/'probe-points.json').read_bytes())
    out=defaultdict(lambda:defaultdict(list))
    def add(typ,key,config):
        z,x,y=config['tile'];p=config['pixel']
        assert len(p)==2 and all(0<=v<=255 for v in p)
        out[groupof(z,x,edges)][zxy_to_tileid(z,x,y)].append((typ,key,config))
    for k,v in allp.items():add('independent',k,v)
    centres=json.loads((root/'centres-input.json').read_bytes())
    for sheet,parts in centres.items():
        for key,pt in parts.items():
            t,p=pixel(*pt);add('centres',key,{'tile':t,'pixel':p,'sheet':sheet})
    for sheet,pt in json.loads((root/'restored-centres.json').read_bytes()).items():
        t,p=pixel(*pt);add('restored',sheet,{'tile':t,'pixel':p,'sheet':sheet})
    return out

def part_bins(rows,g):
    def split(items,depth=0):
        if sum(r.n+24 for r in items)<LIMIT:
            return [items]
        levels=sorted({r.z for r in items})
        if g==0 and len(levels)>1:sort_key=lambda r:r.z
        elif depth==0 or (g==0 and len(levels)==1 and depth==1):
            base=min(levels);sort_key=lambda r:r.x>>(r.z-base)
        elif depth<=2:
            base=min(levels);sort_key=lambda r:r.y>>(r.z-base)
        elif len(levels)>1:sort_key=lambda r:r.z
        else:raise ValueError(('One geographic cell exceeds maximum part size',g,levels))
        bins=defaultdict(list)
        for r in items:bins[sort_key(r)].append(r)
        if len(bins)==1:return split(items,depth+1)
        chunks=[];pending=[];cost=0
        for k,group in sorted(bins.items()):
            size=sum(r.n+24 for r in group)
            if pending and cost+size>=LIMIT:
                chunks.append(pending);pending=[];cost=0
            if size>=LIMIT:chunks.extend(split(group,depth+1))
            else:pending.extend(group);cost+=size
        if pending:chunks.append(pending)
        return chunks
    return split(rows)

def load_rows(root,asset,g,oldmap,con,edges):
    head,entries=walk_entries((root/'old-dirs'/(asset['name']+'.prefix')).read_bytes())
    rows={};stats=Counter();oldlevels=Counter();outlevels=Counter()
    for e in entries:
        off=head['tile_data_offset']+e.offset
        for t in range(e.tile_id,e.tile_id+e.run_length):
            z,x,y=tileid_to_zxy(t);assert groupof(z,x,edges)==g,(t,g)
            assert t not in rows;rows[t]=Row(t,z,x,y,e.length,off,None);oldlevels[z]+=1
    stats['old']=len(rows);assert stats['old']==head['addressed_tiles_count']
    for t,z,x,y,n,sha,keep in con.execute('select tid,z,x,y,n,h,keep from patch where g=?',(g,)):
        prev=rows.pop(t,None)
        if prev:stats['old_affected']+=1
        if keep:
            rows[t]=Row(t,z,x,y,n,-1,sha);stats['patch_tiles']+=1
        else:stats['tombstones']+=1
    stats['untouched_tiles']=stats['old']-stats['old_affected'];stats['output_tiles']=len(rows)
    assert stats['untouched_tiles']+stats['patch_tiles']==len(rows)
    for r in rows.values():outlevels[r.z]+=1
    # Link every cached overview-child byte to the fully downloaded, SHA-pinned previous archive.
    with sqlite3.connect(f'file:{root}/old-dirs/cache.sqlite?mode=ro',uri=True) as previous:
        for ptr,b in previous.execute('select p,payload from blobs where p>=? and p<?',((g+1)<<56,(g+2)<<56)):
            off=ptr&0xffffffff;n=(ptr>>32)&0xffffff
            assert b==oldmap[off:off+n];stats['verified_cached_contents']+=1
    return rows,stats,oldlevels,outlevels

def payload(root,old,r):
    if r.sha is None:return old[r.offset:r.offset+r.n]
    path=root/'tiles'/str(r.z)/str(r.x)/(str(r.y)+'.webp')
    data=path.read_bytes();assert len(data)==r.n and hashlib.sha256(data).digest()==r.sha,path
    return data

def sample_tile(probes,k,raw,name,results):
    if not probes:return
    if raw is not None:
        h=hashlib.sha256(raw).hexdigest();im=Image.open(io.BytesIO(raw));assert im.size==(256,256);im=im.convert('RGBA')
    else:h=None;im=None
    for typ,key,v in probes:
        rgba=list(im.getpixel(tuple(v['pixel']))) if im else None
        if typ in ('centres','restored'):assert rgba and rgba[3]>0,(typ,key,v,rgba)
        resp={'tile':v['tile'],'pixel':v['pixel'],'sha256':h,'rgba':rgba,'part':name}
        if 'sheet' in v:resp['sheet']=v['sheet']
        results[typ][key]=resp

def write_verify(root,rows,old,path,meta,probes,results):
    rows=sorted(rows,key=lambda r:r.tid)
    h,slice_header=bounds_of(rows)
    with path.with_suffix('.partial').open('wb') as dest:
        writer=pm_writer.Writer(dest)
        for r in rows:writer.write_tile(r.tid,payload(root,old,r))
        writer.finalize(h,meta)
    path.with_suffix('.partial').replace(path)
    count=len(rows);choose={0,count//4,count//2,3*count//4,count-1}
    for predicate in (True,False):
        n=next((i for i,r in enumerate(rows) if (r.sha is None)==predicate),None)
        if n is not None:choose.add(n)
    range_probes=[]
    with path.open('rb') as out, mmap.mmap(out.fileno(),0,access=mmap.ACCESS_READ) as mm:
        assert 0<len(mm)<2**31
        head=deserialize_header(mm[:127]);prefix=mm[:head['tile_data_offset']]
        src=Reader(lambda off,n:mm[off:off+n])
        assert src.metadata()==meta and src.header()['addressed_tiles_count']==count
        assert head['tile_type']==TileType.WEBP and head['tile_compression']==Compression.NONE
        _,entries=walk_entries(prefix);iterator=iter(rows);n=0
        for e in entries:
            off=head['tile_data_offset']+e.offset
            assert off+e.length<=len(mm)
            data=mm[off:off+e.length]
            for tid in range(e.tile_id,e.tile_id+e.run_length):
                r=next(iterator);assert r.tid==tid and r.n==e.length
                assert payload(root,old,r)==data,(r,'output payload differs')
                sample_tile(probes.get(tid),tid,data,path.name,results)
                if n in choose:
                    assert src.get(r.z,r.x,r.y)==data
                    range_probes.append({'z':r.z,'x':r.x,'y':r.y,'part':path.name,'sha256':hashlib.sha256(data).hexdigest()})
                n+=1
        assert n==count and next(iterator,None) is None
    return {'name':path.name,'size':path.stat().st_size,'sha256':digest(path),'header':slice_header,'pmtiles_header':convert_header(h,HEADER_EXPORT_KEYS),'probes':range_probes,'tiles':count}

def main(root):
    from publish50 import upload,remote_range_probes
    p=root/'pack';p.mkdir(exist_ok=True);log=p/'groups';log.mkdir(exist_ok=True)
    assert (root/'old-dirs/cache-ready.json').is_file()
    patch=build(root);meta=json.loads((root/'tiles/metadata.json').read_bytes());attr_check(meta)
    data=json.loads((root/'plan.json').read_bytes());manifest,assets=records(root);edges=boundaries(manifest)
    con=sqlite3.connect(f'file:{p}/patch.sqlite?mode=ro',uri=True)
    sig=patch['patch_content_sha256'][:10]
    prefix='Soviet-GS-50k-20261124-'+sig
    ex=WORK/'export';ex.mkdir(parents=True,exist_ok=True)
    spool=WORK/'spool';spool.mkdir(exist_ok=True);tempfile.tempdir=str(spool)
    incoming=probe_plan(root,edges);total=0;receipts=[]
    refsha={n:digest(root/n) for n in ('probe-points.json','centres-input.json','restored-centres.json','plan.json','old-mosaic.json','baseline-pmtiles.json','patch-ready.json','tiles/metadata.json')}
    for g,asset in enumerate(assets):
        done=log/(f'{g:02}.json')
        if done.is_file():
            receipt=json.loads(done.read_bytes());assert receipt['references']==refsha and receipt['prefix']==prefix
            total+=len(receipt['files']);receipts.append(receipt);continue
        source=full(root,asset);assert shutil.disk_usage(WORK).free>5_000_000_000
        results={'centres':{},'restored':{},'independent':{}}
        with source.open('rb') as of, mmap.mmap(of.fileno(),0,access=mmap.ACCESS_READ) as old:
            rows,stats,oldlevels,outlevels=load_rows(root,asset,g,old,con,edges)
            for tid,q in incoming[g].items():
                if tid not in rows:sample_tile(q,tid,None,None,results)
            bins=part_bins(list(rows.values()),g)
            del rows
            files=[]
            for items in bins:
                file=ex/(prefix+f'-part{total:04}.pmtiles')
                info=write_verify(root,items,old,file,meta,incoming[g],results)
                print('Entire output part verified',file.name,info['tiles'],info['size'],flush=True)
                assetrec=upload(file,info['sha256'],p)
                remote_range_probes(assetrec,info)
                files.append({**info,**assetrec});total+=1
                # Only this job's private copy is discarded, after public verification.
                assert file.parent==ex;file.unlink()
        receipt={'group':g,'old':asset['name'],'old_sha256':asset['digest'][7:],'prefix':prefix,'references':refsha,'stats':stats,'oldlevels':oldlevels,'outlevels':outlevels,'files':files,'samples':results}
        write_json(done,receipt);receipts.append(receipt)
        assert source.parent==WORK/'baseline' and source.name==asset['name'];source.unlink()
        print('Completed source stripe',g,'of',len(assets)-1,stats,flush=True)
    from publish50 import finish
    finish(root,patch,meta,receipts,refsha,prefix)
    con.close()

if __name__=='__main__':
    root=Path.cwd()
    while not (root/'patch-ready.json').is_file() or not (root/'old-dirs/cache-ready.json').is_file():time.sleep(12)
    (root/'pack').mkdir(exist_ok=True)
    with (root/'pack/worker.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        main(root)
