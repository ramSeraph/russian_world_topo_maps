"""Verify the streaming source stripe assignment for every logical baseline tile before packing."""
from collections import Counter
from pathlib import Path
from pmtiles.tile import tileid_to_zxy
from patchindex50 import groupof,boundaries
from archives50 import records,walk_entries,write_json
p=Path.cwd();manifest,assets=records(p);edges=boundaries(manifest);parts={}
for g,a in enumerate(assets):
 h,entries=walk_entries((p/'old-dirs'/(a['name']+'.prefix')).read_bytes())
 counts=Counter()
 for e in entries:
    for tid in range(e.tile_id,e.tile_id+e.run_length):
      z,x,y=tileid_to_zxy(tid)
      assert groupof(z,x,edges)==g,(g,tid,z,x,y)
      counts[z]+=1
 assert sum(counts.values())==h['addressed_tiles_count'];parts[a['name']]=counts
 print('Source routing valid',g,sum(counts.values()),flush=True)
write_json(p/'old-dirs/stripe-routing.json',{'counts':parts,'total':sum(sum(v.values()) for v in parts.values())})
