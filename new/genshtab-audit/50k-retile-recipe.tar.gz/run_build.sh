#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
exec 9>orchestrator.lock
flock -n 9 || exit 0
export PYTHONPATH="$PWD:/usr/lib/python3/dist-packages"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 GDAL_PAM_ENABLED=NO GDAL_NUM_THREADS=1
tile_store="/home/ubuntu/rwt-50k-retile-20261124-tiles"
mkdir -p "$tile_store"
if [ ! -e tiles ]; then ln -s "$tile_store" tiles; fi
test "$(realpath tiles)" = "$tile_store"
if [ ! -s sources-ready.json ]; then
    python3 -u get_inputs.py > inputs.log 2>&1 &
    inputs=$!
    echo "$inputs" > inputs.pid
else
    inputs=""
fi
python3 -u archives50.py > old-index.log 2>&1
python3 -u prefetch50.py > prefetch.log 2>&1
python3 -u old_affected50.py > old-affected.log 2>&1
if [ -n "$inputs" ]; then wait "$inputs"; fi
test -s sources-ready.json
if [ ! -s patch-ready.json ]; then bash start.sh >> render.log 2>&1; fi
python3 -u probe_render.py 320 > source-comparison.log 2>&1
