"""Count old tile IDs inside and outside the proposed patch independently of packaging."""
from collections import Counter
from pathlib import Path
import json
import numpy as np
from pmtiles.tile import zxy_to_tileid
from archives50 import digest,write_json
p=Path.cwd()
idx=np.load(p/'old-dirs/index.npy',mmap_mode='r')
plan=json.loads((p/'plan.json').read_bytes())
with (p/'affected-base.xyz').open() as f:want={(x,y) for z,x,y in (map(int,line.split()) for line in f)}
by={};total=int(np.count_nonzero(idx));inside=outside=0
for z in range(14,-1,-1):
    assert len(want)==plan['levels'][str(z)]
    n=sum(bool(idx[zxy_to_tileid(z,x,y)]) for x,y in want)
    by[z]={'affected':len(want),'old_present':n,'old_absent':len(want)-n}
    inside+=n;outside+=len(want)-n
    want={(x//2,y//2) for x,y in want}
d={'old':total,'old_inside_patch':inside,'old_outside_patch':total-inside,'patch_with_no_old':outside,'base_sha256':digest(p/'affected-base.xyz'),'per_zoom':by}
write_json(p/'old-dirs/old-affected.json',d)
print('Existing tiles inside patch',inside,'existing outside patch',total-inside,'new/tombstone coordinates without old',outside,flush=True)
