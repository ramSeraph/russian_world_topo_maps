"""Batch the old child tiles needed for unchanged siblings in retiled overviews."""
from concurrent.futures import ThreadPoolExecutor
from collections import Counter,defaultdict
from pathlib import Path
import itertools
import json
import os
import sqlite3
import threading
import time
from pmtiles.tile import zxy_to_tileid
from archives50 import Old, Ranges, digest, write_json

def main(root):
    coords=root/'unchanged-children.xyz'
    while not coords.is_file():time.sleep(2)
    old=Old(root);store=old.store
    till={}
    levels=Counter()
    for ln in coords.read_text().splitlines():
        z,x,y=map(int,ln.split());tid=zxy_to_tileid(z,x,y);assert tid not in till
        till[tid]=int(old.index[tid]);levels[z]+=1
    plan=json.loads((root/'plan.json').read_bytes())
    assert len(till)==sum(plan['unchanged_children'].values())
    pointers=sorted(set(till.values())-{0})
    db=sqlite3.connect(store/'cache.sqlite',timeout=120);db.execute('PRAGMA journal_mode=WAL');db.execute('PRAGMA synchronous=FULL')
    db.execute('CREATE TABLE IF NOT EXISTS blobs(p INTEGER PRIMARY KEY,payload BLOB NOT NULL)')
    have={p for p,n in db.execute('select p,length(payload) from blobs') if n==(p>>32)&0xffffff}
    by_part=defaultdict(list)
    for p in pointers:
        if p not in have:by_part[(p>>56)-1].append((p&0xffffffff,(p>>32)&0xffffff,p))
    chunks=[];physical=0
    for group,rs in by_part.items():
        chunk=[];start=0;end=0
        for offset,length,p in sorted(rs):
            if chunk and (offset-end>98_304 or offset+length-start>4_000_000):
                chunks.append((group,start,end,chunk))
                chunk=[]
            if not chunk:start=offset
            end=max(offset+length,end);chunk.append((offset,length,p))
        if chunk:chunks.append((group,start,end,chunk))
    # Interleave by part so a single slow release-asset edge doesn't block all workers.
    chunks.sort(key=lambda ch:ch[1])
    physical=sum(c[2]-c[1] for c in chunks)
    print('Requests',len(till),'existing',sum(bool(p) for p in till.values()),'unique',len(pointers),'ranges',len(chunks),'download MB',round(physical/1e6,1),flush=True)
    worker=threading.local()
    def fetch(ch):
        g,start,end,block=ch
        if not hasattr(worker,'src'):worker.src={}
        if g not in worker.src:worker.src[g]=Ranges(old.assets[g])
        data=worker.src[g].read(start,end-start)
        items=[]
        for offset,length,p in block:
            raw=data[offset-start:offset-start+length]
            assert len(raw)==length and raw[:4]==b'RIFF' and raw[8:12]==b'WEBP',(p,offset,length)
            items.append((p,raw))
        return items
    with ThreadPoolExecutor(9) as ex:
        for j in range(0,len(chunks),36):
            for items in ex.map(fetch,chunks[j:j+36]):
                db.executemany('insert or ignore into blobs values(?,?)',items)
            db.commit()
            print('Prefetched',min(j+36,len(chunks)),'/',len(chunks),'groups',flush=True)
    after=dict(db.execute('select p,length(payload) from blobs'))
    assert all(after.get(p)==(p>>32)&0xffffff for p in pointers)
    db.execute('PRAGMA wal_checkpoint(TRUNCATE)');db.close();old.cleanup()
    ready={'request_sha256':digest(coords),'requested_ids':len(till),'requested_unique_content_count':len(pointers),'existing_tiles':sum(bool(p) for p in till.values()),'cached_bytes':sum((p>>32)&0xffffff for p in pointers),'levels':levels}
    write_json(store/'cache-ready.json',ready);print('Verified old child cache',ready,flush=True)

if __name__=='__main__':main(Path.cwd())
