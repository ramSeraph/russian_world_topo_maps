"""Report and resume interrupted workers belonging to this specific 1:50k update."""
import fcntl,json,os,re,shutil,subprocess,sys,time
from pathlib import Path

root=Path(__file__).resolve().parent
os.chdir(root)
def alive(name):
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            args=(proc/'cmdline').read_bytes().split(b'\0')
            if (proc/'cwd').resolve()==root and name.encode() in args:
                return True
        except OSError:pass
    return False

def tail(name,n=16384):
    p=root/name
    if not p.exists():return ''
    with p.open('rb') as f:
        f.seek(max(0,p.stat().st_size-n));return f.read().decode(errors='replace')
def ensure(script,done,log):
    if done or alive(script):return
    path=root/(script+'.retry.json')
    retries=json.loads(path.read_bytes()) if path.exists() else []
    if retries and time.time()-retries[-1]<min(3600,60*2**min(6,len(retries)-1)):return
    with (root/log).open('ab') as stream:
        p=subprocess.Popen(['bash',script],cwd=root,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    path.write_text(json.dumps([*retries,time.time()]))
    (root/(script+'.pid')).write_text(str(p.pid))

def main():
    guard=(root/'supervision.lock').open('a')
    fcntl.flock(guard,fcntl.LOCK_EX)
    ready=(root/'patch-ready.json').is_file()
    compared=(root/'render-cog-samples-320.json').is_file()
    done=(root/'pack/package-done.tar.gz').is_file()
    if '--ensure' in sys.argv:
        ensure('run_build.sh',ready and compared,'build.log')
        ensure('run_pack.sh',done,'pack.log')
    rr=tail('render.log')
    stage='checking inputs'
    if (root/'render-identity.json').is_file():stage='rendering base tiles'
    if 'handling level' in rr:stage='building overviews'
    if ready:stage='checking or packing completed render'
    if done:stage='dated parts and descriptor uploaded'
    tiles=re.findall(r'Completed base batch (\d+)/(\d+) \((\d+)/(\d+) tiles\)',rr)
    db={'stage':stage,'base_target':660178,'base_tiles':660178 if ready or 'handling level' in rr else int(tiles[-1][2]) if tiles else 0,
        'build_process':alive('run_build.sh'),'pack_process':alive('run_pack.sh'),'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
        'free_tile_gib':round(shutil.disk_usage(root/'tiles').free/2**30,1),
        'free_staging_gib':round(shutil.disk_usage(root).free/2**30,1),'complete_old_parts':len(list((root/'pack/groups').glob('*.json')))}
    f=root/'render-status.tmp';f.write_text(json.dumps(db,indent=2)+'\n');f.replace(root/'render-status.json')
    print(json.dumps(db))
if __name__=='__main__':main()
