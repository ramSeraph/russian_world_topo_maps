"""Run the project's GDAL retile and account for every modified/missing overview tile."""
from pathlib import Path
import fcntl
import hashlib
import json
import os
import shlex
import subprocess
import time

import mercantile
from topo_map_processor.tools import retile
from archives50 import previous

job=Path.cwd()
tiles=job/'tiles'
plan=json.loads((job/'plan.json').read_bytes())
zoom=plan['base_zoom']
assert zoom==14
lock=(job/'render.lock').open('a')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
while not (job/'sources-ready.json').is_file():
    try:
        os.kill(int((job/'inputs.pid').read_text()),0)
    except ProcessLookupError:
        raise RuntimeError('COG verification stopped without a completion receipt. See inputs.log.') from None
    time.sleep(5)
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
checked=json.loads((job/'sources-ready.json').read_bytes())
assert checked['source_register_sha256']==sha(job/'sources.json') and checked['verified']==plan['required_cogs']
def save(path,obj):
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(obj,indent=2)+'\n')
    tmp.replace(path)
manifest=json.loads((job/'old-mosaic.json').read_bytes())
assert sha(job/'old-mosaic.json')=='434403afc777eddd905d78fa6db0477d7452d99e4a7f52bfdb321c083ce028dc'
identity={n:sha(job/n) for n in ('plan.json','old-mosaic.json','sources.json','affected-bounds.geojson','retile-sheets.txt','affected-base.xyz','topo_map_processor/tools/retile.py')}
identity.update(tile_quality=75,zoom=zoom)
pinned=job/'render-identity.json'
if pinned.exists():
    assert json.loads(pinned.read_bytes())==identity
else:
    assert not tiles.exists() or (tiles.is_dir() and not any(tiles.iterdir()))
    save(pinned,identity)
if (job/'patch-ready.json').exists():
    print('Verified render already complete.',flush=True)
    raise SystemExit(0)

# The library commits all files of a geographic batch from a temporary directory.
# After interruption, skip only fully committed batches from the identical input set.
baseline_batches=retile.base_tile_batches
def resumable(base_tiles,size=32):
    batches=baseline_batches(base_tiles,size)
    if not (tiles/str(zoom)).exists():
        return batches
    retained=[]
    for batch in batches:
        def intact(tile):
            f=tiles/str(zoom)/str(tile.x)/(str(tile.y)+'.webp')
            return f.is_file() and f.stat().st_size>=12
        if not all(intact(t) for t in batch):
            retained.append(batch)
    print('Reusing',len(batches)-len(retained),'complete base batches of',len(batches),flush=True)
    return retained
retile.base_tile_batches=resumable
# Linux limits the length of one /bin/sh -c argument. Use GDAL's ordered input
# list for the thousands of sources in this VRT, preserving the retile grid.
run_external=retile.run_external
def run_vrt_command(command):
    args=shlex.split(command)
    if args and args[0]=='gdalbuildvrt' and len(args)>2:
        paths=job/'vrt-input-files.txt'
        paths.write_text(''.join(n+'\n' for n in args[2:]))
        subprocess.run(['gdalbuildvrt','-input_file_list',str(paths),args[1]],check=True)
    else:
        run_external(command)
retile.run_external=run_vrt_command
old=previous(job)
retile.create_source_from_paths=lambda paths:old
initial=retile.assess_sheet_requirements
def check_plan(*args):
    sources,base_tiles=initial(*args)
    assert sources==set((job/'required.txt').read_text().splitlines())
    with (job/'affected-base.xyz').open() as stream:
        keys={tuple(map(int,line.split())) for line in stream}
    assert {(t.z,t.x,t.y) for t in base_tiles}==keys and len(keys)==plan['levels'][str(zoom)]
    return sources,base_tiles
retile.assess_sheet_requirements=check_plan
try:
    result=retile.retile_main(['--retile-list-file','retile-sheets.txt','--bounds-file','affected-bounds.geojson',
        '--from-source','old-mosaic.json','--tiffs-dir','sources','--tiles-dir',str(tiles.resolve()),
        '--num-parallel',os.getenv('RETILE_WORKERS','12'),'--batch-size','32','--tile-quality','75'])
    assert result==0
finally:
    old.cleanup()
metadata_file=tiles/'metadata.json'
metadata=json.loads(metadata_file.read_bytes())
assert metadata['format']=='webp' and metadata['minzoom']==0 and metadata['maxzoom']==zoom
metadata['attribution']=manifest['metadata']['attribution']+'; <a href="https://archive.org/details/genshtab-100k-50k-europe-asia">Genshtab scans on the Internet Archive</a>; Reproduced with permission from <a href="http://redatlasbook.com">http://redatlasbook.com</a> for non-commercial purposes.'
save(metadata_file,metadata)
with (job/'affected-base.xyz').open() as stream:
    level={(x,y) for _,x,y in (map(int,line.split()) for line in stream)}
for z in range(zoom,-1,-1):
    actual={(int(f.parent.name),int(f.stem)) for f in (tiles/str(z)).glob('*/*.webp')}
    assert actual==level and len(actual)==plan['levels'][str(z)], (z,len(level),len(actual))
    level={(x//2,y//2) for x,y in level}
result=dict(identity=identity,base_zoom=zoom,levels=plan['levels'],affected_base_file='affected-base.xyz',sources=checked,metadata_sha256=sha(metadata_file))
save(job/'patch-ready.json',result)
print('Verified',sum(plan['levels'].values()),'affected tiles across all 15 zooms.',flush=True)
