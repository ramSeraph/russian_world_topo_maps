"""Record independent public pixel positions for each new cell and the corrected historical extents."""
from pathlib import Path
import json,math
import mercantile
from shapely.geometry import shape

job=Path(__file__).resolve().parent
audit=job.parents[2]
data=json.loads((job/'centres-input.json').read_bytes())
bounds=json.loads((audit/'staging/rwt-50k-metadata-20261122/final/bounds.geojson').read_bytes())
features={f['properties']['id']:f for f in bounds['features']}
result={}
def add(key,kind,sheet,coords,z=14):
    lon,lat=coords;t=mercantile.tile(lon,lat,z)
    px=max(0,min(255,int(((lon+180)/360*(1<<z)-t.x)*256)))
    py=max(0,min(255,int(((1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*(1<<z)-t.y)*256)))
    result[key]=dict(kind=kind,sheet=sheet,tile=[z,t.x,t.y],pixel=[px,py])
for sheet,cells in data.items():
    for key,xy in cells.items():add(key,'component centre',sheet,xy)
historical=json.loads((job/'restored-centres.json').read_bytes())
for k,xy in historical.items():
    f=features[k];g=shape(f['geometry']);old=shape(json.loads(f['properties']['source_graticule_wgs84']))
    add('mask-inside/'+k,'measured inside',k,xy)
    extra=old.difference(g)
    if not extra.is_empty:
        area=max(getattr(extra,'geoms',[extra]),key=lambda p:p.area)
        add('mask-exterior/'+k,'prior extent outside valid mask',k,area.representative_point().coords[0])
with (job/'affected-base.xyz').open() as f:
    affected={tuple(map(int,line.split())) for line in f}
candidates=[]
for n,f in sorted(features.items()):
    if n in data or n in historical:continue
    lon,lat=shape(f['geometry']).representative_point().coords[0]
    tile=mercantile.tile(lon,lat,14)
    candidates.append((n,[lon,lat],(tile.z,tile.x,tile.y)))
chosen=set()
for i in range(16):
    start=i*(len(candidates)-1)//15
    for step in range(len(candidates)):
        n,xy,address=candidates[(start+step)%len(candidates)]
        if address not in affected and address not in chosen:
            add('legacy/'+n,'unchanged historical',n,xy)
            chosen.add(address)
            break
assert len(chosen)==16
keys=sorted(data)
for z in range(14):
    k=keys[z*(len(keys)-1)//13]
    add('overview/'+str(z),'overview',k,next(iter(data[k].values())),z)
assert sum(v['kind']=='component centre' for v in result.values())==4470
(job/'probe-points.json').write_text(json.dumps(result,separators=(',',':'))+'\n')
print('Public proof positions:',len(result),'distinct tiles:',len({tuple(v['tile']) for v in result.values()}))
