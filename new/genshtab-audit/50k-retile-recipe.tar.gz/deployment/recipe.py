"""Freeze only the retile inputs, workflow and final verification records."""
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
job=Path(__file__).resolve().parent
audit=job.parents[1]
def freeze(final=False):
    entries={}
    def add(name,path):entries[name]=path.read_bytes()
    render=job/'render'
    for p in sorted(render.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:
            add(str(p.relative_to(render)),p)
    for n in ('complete.py','live_xyz.py','publish_pages.py','publish_route.py','before-public-xyz.json'):
        p=job/'deploy'/n
        if p.exists():add('deployment/'+n,p)
    add('deployment/collect50.py',job/'package/collect50.py')
    for n in ('watch.py','recipe.py','org.rwt.50k-pmtiles-20261124.plist'):
        add('deployment/'+n,job/n)
    if final:
        finaldir=job/'fixtures'
        names=['patch-ready.json','render-cog-samples-320.json','sources-ready.json','pilot-verification.json','old-dirs/old-affected.json','old-dirs/stripe-routing.json']
        host=Path('/Users/ram/Code/american_world_topo_maps/jog/build-host')
        subprocess.run([str(host),'pull',*['scratch/rwt-50k-retile-20261124/'+n for n in names],'--to',str(finaldir)+'/'],cwd=host.parent,check=True)
        for n in names:add('verification/'+Path(n).name,finaldir/Path(n).name)
        for n in ('route-receipt.json','pages-receipt.json','public-part-headers.json','pack-verification.json','dated-assets-published.json','live-xyz-verification.json'):
            add('verification/'+n,job/'deploy'/n)
        add('verification/50k-pmtiles-verification.json',audit/'50k-pmtiles-verification.json')
    entries['BUILD.txt']=b"""Soviet General Staff 1:50,000 mosaic update, November 2026

The input manifest pins all 16 original PMTiles files and every required published COG. The spatial plan uses the 4,387 new published sheets, ten corrections to historical validity-mask bounds and 662 neighboring TIFFs. Joined scans remain single raster sources. Probe positions cover the 4,470 new geographic cells.

The rendering uses the enclosed topo_map_processor retile tool from commit 81c3a9a57d29e4fe637968426dd5fb9864aa236f and gh-release-tools from 53248f24ef13ea8497f35b4ddb0d7f0e40e76cb4. Original zoom levels 0-14, 256-pixel WebP, Lanczos resampling and WebP quality 75 are retained. The working host supplies GDAL, its Python bindings, mercantile, shapely, numpy, requests, pmtiles, pmtiles_mosaic, Pillow and OpenCV. The rendering command is in start.sh.

The included generated plan can be used directly. prepare.py and points.py show how it was derived using the collection release and coverage audit. On the staging host run run_build.sh in a fresh directory and run_pack.sh separately. The example run_build.sh stores the render on the host root volume and reads selected verified sheets from its adjacent original staging directory. get_inputs.py downloads any other required TIFF from the pinned GitHub release. Periodic status.py --ensure calls resume interrupted workers. The packer writes versioned release parts after verifying every output against the original or rerendered tile. Packaging is a publishing operation and needs GitHub credentials. The undated mosaic descriptor and bounds are switched by the separate deployment scripts only after the dated outputs have all passed public checks. Absolute paths in the deployment scripts describe this installation.
"""
    entries['SHA256.json']=(json.dumps({k:hashlib.sha256(v).hexdigest() for k,v in entries.items()},indent=2,sort_keys=True)+'\n').encode()
    target=audit/'50k-retile-recipe.tar.gz';temp=target.with_suffix('.tmp')
    with temp.open('wb') as out,gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
        for n,b in sorted(entries.items()):
            item=tarfile.TarInfo(n);item.size=len(b);item.mode=0o755 if n.endswith('.sh') else 0o644
            tar.addfile(item,io.BytesIO(b))
    with tarfile.open(temp) as tar:
        assert {m.name for m in tar}==set(entries)
        for n,b in entries.items():assert tar.extractfile(n).read()==b
    temp.replace(target)
if __name__=='__main__':freeze()
