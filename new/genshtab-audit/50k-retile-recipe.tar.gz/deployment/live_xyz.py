"""Sample published XYZ directly, checkpointing only tile bytes that match the verified PMTiles output."""
from collections import Counter,defaultdict
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,io,json,os,sys,threading,time
from pathlib import Path
from PIL import Image
import requests

P=Path(__file__).parent
BASE='https://indianopenmaps.com/world/topo/russian/50k/gs/'
POINTS=json.loads((P/'probe-points.json').read_bytes())
RESTORED=set(json.loads((P.parent/'render/restored-centres.json').read_bytes()))
LOCAL=threading.local()
def sha(data):return hashlib.sha256(data).hexdigest()
def dump(p,d):
    t=p.with_suffix('.tmp');t.write_text(json.dumps(d,separators=(',',':'))+'\n');t.replace(p)
def response(path,params=None):
    if not hasattr(LOCAL,'session'):LOCAL.session=requests.Session()
    r=LOCAL.session.get(BASE+path,params=params,timeout=(10,42),headers={'Accept-Encoding':'identity'})
    if r.status_code not in (200,404):r.raise_for_status()
    return r
def tile(t,indices):
    z,x,y=t;url=f'{z}/{x}/{y}.webp';r=response(url)
    if r.status_code==404:return {'tile':list(t),'status':404,'sha256':None,'pixels':{k:None for k in indices}}
    data=r.content
    with Image.open(io.BytesIO(data)) as im:
        assert im.format=='WEBP' and im.size==(256,256),(url,im.size,im.format)
        rgba=im.convert('RGBA')
        return {'tile':list(t),'status':200,'sha256':sha(data),'all_transparent':rgba.getchannel('A').getextrema()==(0,0),
                'pixels':{k:list(rgba.getpixel(tuple(POINTS[k]['pixel']))) for k in indices}}
def baseline():
    ids={k for k in POINTS if '/' in k}
    cells=sorted(k for k in POINTS if '/' not in k)
    ids.update(cells[i*(len(cells)-1)//11] for i in range(12))
    groups=defaultdict(list)
    for k in sorted(ids):groups[tuple(POINTS[k]['tile'])].append(k)
    path=P/'before-public-xyz.json'
    saved=json.loads(path.read_bytes()) if path.is_file() else {}
    def job(t,keys):
        for i in range(4):
            try:return tile(t,keys)
            except (AssertionError,OSError,ValueError,requests.RequestException):
                if i==3:raise
                time.sleep(2**i)
    with ThreadPoolExecutor(5) as pool:
        futures={pool.submit(job,t,keys):t for t,keys in groups.items() if not all(k in saved for k in keys)}
        for fut in as_completed(futures):
            t=futures[fut];r=fut.result()
            for k,pix in r['pixels'].items():saved[k]={'tile':r['tile'],'status':r['status'],'sha256':r['sha256'],'rgba':pix}
            dump(path,saved)
    print('Baseline checked',len(saved),'points,',Counter(i['status'] for i in saved.values()))
def live():
    marker=json.loads((P/'dated-assets-published.json').read_bytes()); rev=marker['descriptor']['sha256']
    expected=json.loads((P/'independent-expected.json').read_bytes())
    assert set(expected)==set(POINTS),(len(expected),len(POINTS))
    groups=defaultdict(list)
    for k,pt in POINTS.items():
        e=expected[k]
        assert e['tile']==pt['tile'] and e['pixel']==pt['pixel'],k
        if pt['kind'] in ('component centre','interior of measured partial footprint','measured inside'):
            assert e['sha256'] and e['rgba'][3]>0,k
        groups[tuple(pt['tile'])].append(k)
    before=json.loads((P/'before-public-xyz.json').read_bytes())
    statepath=P/'live-centres-progress.jsonl';success={}
    if statepath.exists():
        for line in statepath.read_text().splitlines():
            if not line.strip():continue
            x=json.loads(line)
            if x['revision']==rev:success[tuple(x['tile'])]=x
    def work(t,keys):
        r=tile(t,keys)
        for k,rgba in r['pixels'].items():
            e=expected[k]
            if e['sha256']:
                assert r['sha256']==e['sha256'] and rgba==e['rgba'], (k,r['status'],r['sha256'],e['sha256'])
            elif not (r['status']==404 or r.get('all_transparent')):
                raise ValueError('PMTiles absence disagrees with public image '+k)
        r['revision']=rev;return r
    for attempt in range(80):
        todo={t:g for t,g in groups.items() if t not in success}
        if not todo:break
        issues=[]
        with statepath.open('a') as f,ThreadPoolExecutor(8) as pool:
            futures={pool.submit(work,t,keys):t for t,keys in todo.items()}
            for fut in as_completed(futures):
                try:
                    r=fut.result();success[tuple(r['tile'])]=r
                    f.write(json.dumps(r,separators=(',',':'))+'\n');f.flush()
                    if len(success)%200==0:print(len(success),'of',len(groups),'public XYZ tiles verified',flush=True)
                except (AssertionError,OSError,ValueError,requests.RequestException) as exc:issues.append(str(exc)[:260])
        if issues:print('Remaining',len(groups)-len(success),'examples',issues[:3],flush=True);time.sleep(min(60,4+attempt*3))
    assert set(success)==set(groups),f'{len(groups)-len(success)} stable XYZ tiles are still unverified'
    changed={};preserved={}
    for k,b in before.items():
        r=success[tuple(POINTS[k]['tile'])];pair={'before_sha256':b['sha256'],'after_sha256':r['sha256'],'before_rgba':b['rgba'],'after_rgba':r['pixels'][k]}
        if k.startswith(('seam/','legacy/')) and POINTS[k]['sheet'] not in RESTORED:
            assert b['sha256']==r['sha256'] or (b['sha256'] is None and r.get('all_transparent')),(k,pair)
            preserved[k]=pair
        else:changed[k]=pair
    compact={'revision':rev,'public_route':BASE,'component_points':sum(v['kind'] in ('component centre','interior of measured partial footprint') for v in POINTS.values()),'points':len(POINTS),'unique_tiles':len(success),'nonempty_tiles':sum(r['status']==200 and not r.get('all_transparent') for r in success.values()),'joined_scans':83,'measured_partials':0,'restored':sorted(RESTORED),'overviews':list(range(14)),'historical_and_seam_preservation':preserved,'before_after':changed,'point_inputs_sha256':sha((P/'probe-points.json').read_bytes()),'expected_point_sha256':sha((P/'independent-expected.json').read_bytes())}
    dump(P/'live-xyz-verification.json',compact);print('Verified all public points',len(POINTS),'in',len(success),'tiles')
if __name__=='__main__':
    if sys.argv[1:] == ['baseline']:baseline()
    elif sys.argv[1:] == ['live']:live()
    else:raise SystemExit('pass baseline or live')
