"""Read back all verified dated assets publicly before exposing the route-switch signal."""
import hashlib
import json
import os
import subprocess
import tarfile
import tempfile
import time
from pathlib import Path

os.environ['PATH']='/opt/homebrew/bin:/usr/local/bin:'+os.environ.get('PATH','/usr/bin:/bin')
job=Path(__file__).resolve().parent.parent
deploy=job/'deploy'
host=Path('/Users/ram/Code/american_world_topo_maps/jog/build-host')
remote='scratch/rwt-50k-retile-20261124'
tag='50k-gs-pmtiles';api='repos/ramSeraph/russian_world_topo_maps/releases'
def run(*args,cwd=None):
    r=subprocess.run(args,cwd=cwd,capture_output=True,timeout=210)
    if r.returncode:raise RuntimeError((r.returncode,r.stderr.decode(errors='replace')[-350:]))
    return r.stdout
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def receive():
    with tempfile.TemporaryDirectory(dir=job/'package') as temp:
        tmp=Path(temp)
        run(str(host),'pull',remote+'/pack/package-done.tar.gz','--to',str(tmp)+'/',cwd=host.parent)
        with tarfile.open(tmp/'package-done.tar.gz','r:gz') as tf:
            for m in tf.getmembers():assert m.isfile() and Path(m.name).name==m.name
            tf.extractall(tmp,filter='data')
        ready=tmp/'dated-assets-published.json';report=json.loads(ready.read_bytes());desc=report['descriptor']
        expected={desc['name'],report['canonical'],'centres.json','restored-centres.json','independent-expected.json','pack-verification.json','dated-assets-published.json'}
        assert {f.name for f in tmp.glob('*.json')}==expected
        assert sha(tmp/desc['name'])==sha(tmp/report['canonical'])==desc['sha256']
        assert report['baseline_mosaic_sha256']==sha(job/'render/old-mosaic.json')
        full=json.loads((tmp/'pack-verification.json').read_bytes())
        assert full['stats']['old']==2_230_211 and full['stats']['output_tiles']==report['output_tiles']
        assert len(json.loads((tmp/'centres.json').read_bytes()))==4470 and len(json.loads((tmp/'independent-expected.json').read_bytes()))==4520
        states={r['name']:r for r in json.loads(run('gh','api',api+'/tags/'+tag,'--jq','[.assets[]|{id,name,size,digest,state,browser_download_url}]'))}
        mosaic=json.loads((tmp/desc['name']).read_bytes())
        assert set(mosaic['slices'])==set(report['parts'])
        for a in [desc,*report['parts'].values()]:
            r=states[a['name']]
            assert r['state']=='uploaded' and r['id']==a['id'] and r['browser_download_url']==a['url'] and r['size']==a['size'] and r['digest']=='sha256:'+a['sha256']
        assert run('gh','api',api+'/assets/'+str(desc['id']),'-H','Accept: application/octet-stream')==(tmp/desc['name']).read_bytes()
        deploy.mkdir(exist_ok=True)
        for n in sorted(expected-{'dated-assets-published.json'}):(tmp/n).replace(deploy/n)
        ready.replace(deploy/ready.name)
        print('Independent public GitHub inventory and descriptor verified, route deployment handoff delivered.',flush=True)
def watch():
    while not (deploy/'dated-assets-published.json').is_file():
        try:
            state=run(str(host),'run','bash','-c','cd /mnt/external-512/jog/'+remote+' && if test -s pack/package-done.tar.gz; then echo ready; else echo waiting; fi',cwd=host.parent).strip()
            if state==b'ready':
                receive();break
        except Exception as e:print(type(e).__name__,str(e),flush=True)
        time.sleep(45)
if __name__=='__main__':watch()
