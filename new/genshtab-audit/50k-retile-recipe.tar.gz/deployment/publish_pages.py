"""Prove the stable IOM route, deploy the demo, and check the public Pages index."""
import json, subprocess, time
from pathlib import Path
import requests
from publish_route import P, gh, sha, dump, load, SHAPE, SHAPE_SHA, CANON, BOUNDS, REPO

CHECKOUT=P/'demo-checkout'
PAGE='https://ramseraph.github.io/russian_world_topo_maps/50k/'
XYZ='https://indianopenmaps.com/world/topo/russian/50k/gs/'
FILE='docs/50k/index.html'
TITLE='Update the 1:50k demo credits for the expanded mosaic'
def git(*args):
    return subprocess.check_output(['git','-C',str(CHECKOUT),*args],text=True).strip()
def public(url):
    r=requests.get(url,timeout=(15,90))
    r.raise_for_status()
    return r.content
def live_tilejson(manifest):
    url = XYZ+'tiles.json'
    h = manifest['header']
    extent = [h[k]/1e7 for k in ('min_lon_e7','min_lat_e7','max_lon_e7','max_lat_e7')]
    def matches(d):
        return (d['bounds'] == extent and d['attribution'] == manifest['metadata']['attribution']
                and d['minzoom'] == 0 and d['maxzoom'] == 14 and d['tiles'] == [XYZ+'{z}/{x}/{y}.webp'])
    current = json.loads(public(url))
    if not matches(current):
        # Cloudflare isolates revalidate independently. Exercise another standard client
        # against the identical user-facing URL during the propagation period.
        current = json.loads(subprocess.check_output(['curl','--http2','-fsSL','--max-time','90',url],timeout=100))
    assert matches(current), current
    return current
def demo_commit():
    pinned=P/'pages-commit.json'
    if pinned.is_file():return load(pinned)['commit']
    git('fetch','origin','main')
    assert set(git('diff','--name-only').splitlines())<={FILE}
    assert set(git('diff','--cached','--name-only').splitlines())<={FILE}
    assert not git('ls-files','--others','--exclude-standard')
    if git('status','--porcelain','--',FILE):
        git('add','--',FILE);git('diff','--cached','--check');git('commit','-m',TITLE,'--',FILE)
    assert git('log','-1','--format=%s')==TITLE
    # A new upstream change can be rebased only while our demo commit is still private.
    if subprocess.run(['git','-C',str(CHECKOUT),'merge-base','--is-ancestor','HEAD','origin/main']).returncode:
        git('rebase','origin/main')
        assert git('log','-1','--format=%s')==TITLE and git('diff','--name-only','HEAD~1','HEAD')==FILE
        git('push','origin','HEAD:refs/heads/main')
    head=git('rev-parse','HEAD');dump(pinned,{'commit':head,'repository':REPO});return head
def action(head):
    for _ in range(120):
        runs=json.loads(gh('run','list','--repo',REPO,'--workflow','docs.yml','--commit',head,'--json','databaseId,status,conclusion,url,headSha'))
        if runs:
            run=runs[0];assert run['headSha']==head
            if run['status']=='completed':
                if run['conclusion']!='success':
                    raise RuntimeError('Pages workflow '+str(run))
                return run
        time.sleep(10)
    raise TimeoutError('Pages build has not yet finished')
def main():
    route=load(P/'route-receipt.json');m=load(P/CANON);receipts=route['assets']
    assert sha(public(receipts[CANON]['url']+'?asset='+str(receipts[CANON]['id'])))==receipts[CANON]['sha256']==sha((P/CANON).read_bytes())
    assert sha(public(receipts[BOUNDS]['url']+'?asset='+str(receipts[BOUNDS]['id'])))==receipts[BOUNDS]['sha256']==SHAPE_SHA
    # Let the public tile worker pick up the stable descriptor before changing its demo.
    tj=live_tilejson(m)
    head=demo_commit();run=action(head)
    html=(CHECKOUT/FILE).read_bytes()
    assert b'non-commercial' in html and b'genshtab-100k-50k-europe-asia' in html and b'./index.geojson' in html and (XYZ+'{z}/{x}/{y}.webp').encode() in html
    for _ in range(25):
        live_html=public(PAGE);live_index=public(PAGE+'index.geojson')
        if sha(live_index)==SHAPE_SHA and sha(live_html)==sha(html):break
        time.sleep(12)
    else:raise RuntimeError('Pages is still serving the previous version')
    labels={f['properties']['id'] for f in json.loads(live_index)['features']};assert len(labels)==14252 and {'O40-084-3','K31-008-1','I37-073-2','M33-077-1','L33-131-3'}<=labels
    result={'page':PAGE,'commit':head,'action':run['url'],'action_result':run['conclusion'],'bounds_features':len(labels),'html_sha256':sha(live_html),'index_url':PAGE+'index.geojson','index_sha256':sha(live_index),'public_tilejson':tj,'tilejson_url':XYZ+'tiles.json','verified_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
    dump(P/'pages-receipt.json',result)
    print('Published the demo, confirmed workflow, HTML, full bounds and stable TileJSON.',flush=True)
if __name__=='__main__':main()
