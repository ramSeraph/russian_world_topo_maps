"""Supervise the remote build and publish the checked mosaic to its existing URL."""
import fcntl,json,os,sys,time,traceback
from pathlib import Path
job=Path(__file__).resolve().parent
sys.path[:0]=[str(job/'package'),str(job/'deploy')]
os.environ['PATH']='/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:'+os.environ.get('PATH','')
import collect50
import complete
from live_xyz import baseline

def main():
    lock=(job/'watch.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    while not complete.PUBLIC.is_file():
        try:
            if not (job/'deploy/dated-assets-published.json').is_file():
                prefix='/mnt/external-512/jog/'+collect50.remote
                raw=collect50.run(str(collect50.host),'run','python3',prefix+'/status.py','--ensure',cwd=collect50.host.parent)
                st=json.loads(raw);complete.route.dump(job/'remote-status.json',st)
                prior=job/'deploy/before-public-xyz.json'
                if not prior.is_file() or len(complete.route.load(prior))!=62:baseline()
                if st['stage']=='dated parts and descriptor uploaded':collect50.receive()
            if (job/'deploy/dated-assets-published.json').is_file():
                complete.deploy()
                if complete.PUBLIC.is_file():break
        except Exception as exc:
            complete.progress('retrying',str(exc)[:1800]);traceback.print_exc()
        time.sleep(60)
    from recipe import freeze
    freeze(final=True)
    print('Verified release and coverage, live public mosaic and reproducible retile recipe.',flush=True)
if __name__=='__main__':main()
