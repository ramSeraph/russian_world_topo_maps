"""Switch stable aliases only after dated output handoff, then verify Pages and actual public tiles."""
from pathlib import Path
import fcntl, json, os, subprocess, sys, time, traceback
os.environ['PATH']='/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:'+os.environ.get('PATH','')
import publish_route as route
import publish_pages as pages
import live_xyz as xyz
P=Path(__file__).parent;JOB=P.parent
PUBLIC=Path('/Users/ram/Code/russian_world_topo_maps/new/genshtab-audit/50k-pmtiles-verification.json')
def get(n):return route.load(P/n)
def progress(state,msg=''):
    route.dump(P/'progress.json',{'stage':state,'message':msg,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
def deploy():
    marker=get('dated-assets-published.json');revision=marker['descriptor']['sha256']
    if len(get('before-public-xyz.json'))!=62:raise ValueError('Incomplete predeployment sample')
    if not (P/'route-receipt.json').exists():
        progress('validating dated output and publishing stable aliases')
        route.main()
    stable=get('route-receipt.json');assert stable['assets'][route.CANON]['sha256']==revision
    if not (P/'pages-receipt.json').exists():
        progress('validating live TileJSON and deploying Pages')
        pages.main()
    if not (P/'live-xyz-verification.json').exists():
        progress('checking public XYZ against independently packed points')
        xyz.live()
    proof=get('live-xyz-verification.json');assert proof['revision']==revision
    pages_receipt=get('pages-receipt.json')
    pack=get('pack-verification.json');stats=pack['stats'];render=route.load(JOB/'render/plan.json')
    assert set(pack['patch']['levels'])==set(render['levels']) and pack['patch']['levels']==render['levels']
    assert render['released_bounds_sha256']==stable['assets'][route.BOUNDS]['sha256']==pages_receipt['index_sha256']
    final={'verified_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'released_50k_cogs':stable['bounds_features'],'added_scans':render['new'],'added_cells':proof['component_points'],'joined_scans':proof['joined_scans'],'measured_partials':proof['measured_partials'],'historical_mask_corrections':proof['restored'],'neighboring_cogs':render['neighboring_cogs'],'public_tilejson':pages_receipt['tilejson_url'],'public_demo':pages_receipt['page'],'public_index':pages_receipt['index_url'],'github_pages_commit':pages_receipt['commit'],'github_pages_workflow':pages_receipt['action'],'release_tag':marker['tag'],'stable_aliases':stable['assets'],'dated_descriptor':marker['descriptor'],'dated_parts':marker['parts'],'levels':marker['output_levels'],'previous_tiles':stats['old'],'affected_base_tiles':render['levels'][str(render['base_zoom'])],'affected_tiles':sum(render['levels'].values()),'output_tiles':marker['output_tiles'],'unaffected_tiles_identical':marker['untouched_tiles'],'patch_tiles':marker['patch_tiles'],'tombstones':marker['tombstones'],'dated_input_bytes':pack['all_full_input_bytes'],'dated_output_bytes':pack['all_output_bytes'],'public_centres':proof['component_points'],'public_probe_points':proof['points'],'public_probe_tiles':proof['unique_tiles'],'public_probe_input_sha256':proof['point_inputs_sha256'],'public_expected_pixels_sha256':proof['expected_point_sha256'],'before_after_public_sha256':route.sha((P/'live-xyz-verification.json').read_bytes()),'verified_before_after_points':len(proof['before_after'])+len(proof['historical_and_seam_preservation']),'historical_probes':proof['historical_and_seam_preservation'],'pack_report_sha256':route.sha((P/'pack-verification.json').read_bytes()),'patch_receipt_sha256':marker['patch_receipt_sha256'],'pages_html_sha256':pages_receipt['html_sha256'],'index_sha256':pages_receipt['index_sha256'],'old_mosaic_sha256':marker['baseline_mosaic_sha256']}
    route.dump(PUBLIC,final)
    route.dump(P/'final-verification.json',final)
    progress('complete');print('All 1:50,000 PMTiles, public index, Pages and live XYZ checks complete.',flush=True)
def main():
    lock=(P/'complete.lock').open('a')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:return
    if (P/'final-verification.json').exists():
        if '--wait' in sys.argv:
            subprocess.run(['/bin/launchctl','remove','org.rwt.50k-retile-deploy-20261124'],check=False)
        return
    progress('waiting for verified dated PMTiles assets')
    wait='--wait' in sys.argv
    while not (P/'dated-assets-published.json').exists():
        if not wait:return
        time.sleep(45)
    while not (P/'final-verification.json').exists():
        try:deploy()
        except Exception as exc:
            progress('retrying',str(exc)[:2400]);traceback.print_exc()
            if not wait:raise
            time.sleep(60)
    if wait and (P/'final-verification.json').exists():
        subprocess.run(['/bin/launchctl','remove','org.rwt.50k-retile-deploy-20261124'],check=False)
if __name__=='__main__':main()
