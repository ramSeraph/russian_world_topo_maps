"""Safely replace the two release aliases after the dated PMTiles are verified."""
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
import requests
P=Path(__file__).parent
REPO='ramSeraph/russian_world_topo_maps';TAG='25k-gs-pmtiles';API='repos/'+REPO+'/releases'
CANON='Soviet-GS-25k.mosaic.json';BOUNDS='bounds.geojson'
SHAPE=P.parent/'publication/ready/georef/bounds.geojson'
SHAPE_SHA='96c449d089c0ef0f7d2fcf7c7892626ae27fce862e1994099cf37fd1e4bf28f8'
def gh(*args):return subprocess.check_output(['gh',*args],text=True)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def dump(p,v):
    t=p.with_suffix('.tmp');t.write_text(json.dumps(v,indent=2)+'\n');t.replace(p)
def load(p):return json.loads(p.read_bytes())
def gh_assets(tag=TAG):
    rel=json.loads(gh('api',API+'/tags/'+tag))
    return {r['name']:r for r in rel['assets']}
def exact(a,hs,size):return a and a['state']=='uploaded' and a['digest']=='sha256:'+hs and a['size']==size
def rename(a,n):gh('api','-X','PATCH',API+'/assets/'+str(a['id']),'-f','name='+n,'--silent')
def get(a):
    req=requests.get(a['browser_download_url'],params={'asset':a['id']},timeout=(15,90))
    req.raise_for_status();return req.content
def check_header(arg):
    a,s=arg;url=a['browser_download_url'];h={'Range':'bytes=0-126','Accept-Encoding':'identity'}
    for i in range(5):
        try:
            with requests.get(url,headers=h,params={'pm100':a['id']},stream=True,timeout=(10,45)) as r:
                r.raise_for_status();b=next(r.iter_content(127))
                assert r.status_code==206 and r.headers['Content-Range']==f'bytes 0-126/{a["size"]}',a['name']
                assert len(b)==127 and b[:8]==b'PMTiles\x03' and b[99]==4 and [b[100],b[101]]==[s['header']['min_zoom'],s['header']['max_zoom']],a['name']
            return {'name':a['name'],'id':a['id'],'bytes':a['size'],'header_sha256':sha(b),'minzoom':b[100],'maxzoom':b[101]}
        except (OSError,AssertionError,requests.RequestException):
            if i==4:raise
            time.sleep(2**i)
def stage(name,path,a,old):
    hs=sha(path.read_bytes());size=path.stat().st_size
    previous=name+'.'+old['digest'][7:19]+'.previous';temp=name+'.'+hs[:12]+'.staged'
    if exact(a.get(name),hs,size):return
    held=a.get(name) or a.get(previous)
    assert held and held['id']==old['id'] and held['digest']==old['digest'],('baseline differs',name)
    if temp not in a:
        link=P/'staged'/temp;link.parent.mkdir(exist_ok=True)
        if not link.exists():os.link(path,link)
        assert sha(link.read_bytes())==hs
        gh('release','upload',TAG,str(link),'--repo',REPO)
    staged=gh_assets()[temp]
    assert exact(staged,hs,size) and sha(get(staged))==hs,(name,'staged')
def swap(name,path,old):
    hs=sha(path.read_bytes());size=path.stat().st_size;prev=name+'.'+old['digest'][7:19]+'.previous';temp=name+'.'+hs[:12]+'.staged'
    current=gh_assets()
    if exact(current.get(name),hs,size):return
    assert exact(current.get(temp),hs,size),(name,'staged bytes missing')
    if name in current:
        assert current[name]['id']==old['id'] and current[name]['digest']==old['digest'] and prev not in current,name
        rename(current[name],prev)
    else:assert current[prev]['id']==old['id'] and current[prev]['digest']==old['digest']
    try:rename(current[temp],name)
    except Exception:
        current=gh_assets()
        if name not in current:rename(current[prev],name)
        raise
    assert exact(gh_assets().get(name),hs,size)
def main():
    import sys
    sys.path.insert(0,str(P.parent/'publication/tools'))
    from release_tools import upload_to_release as helper
    from baseline import sha as filehash
    from pmtiles.reader import Reader
    from pmtiles.tile import deserialize_header
    from render import entries
    import mmap
    live=gh_assets();old={a['name']:a for a in load(P/'baseline.json')}
    proof=load(P/'packed.json');points=load(P/'pixel-checks.json');desired=load(P/'public-probes.json')
    assert len(points)==292 and len(desired)>=291 and proof['old_manifest']==filehash(P/'old-mosaic.json')
    georef=gh_assets('25k-gs-georef')[BOUNDS];assert exact(georef,SHAPE_SHA,SHAPE.stat().st_size) and filehash(SHAPE)==SHAPE_SHA and len(load(SHAPE)['features'])==3341
    assert proof['counts']['old_tiles']-proof['counts']['old_affected']+proof['counts']['patch_tiles']==proof['total']
    out=P/'export';d=out/proof['descriptor_name'];m=load(d)
    assert proof['descriptor']==filehash(d)
    assert set(m['slices'])==set(proof['reused'])|{part['name'] for part in proof['parts']}
    assert m['header']==load(P/'old-mosaic.json')['header'] and 'genshtab-latvia-25-k-sk-42' in m['metadata']['attribution']
    for name in proof['reused']:
        assert all(live[name][k]==old[name][k] for k in ('size','digest','id','state')) and m['slices'][name]==load(P/'old-mosaic.json')['slices'][name]
    def upload(f,hs):
        assert filehash(f)==hs
        mark=P/'staged'/(f.name+'.attempt');mark.parent.mkdir(exist_ok=True)
        for i in range(5):
            a=gh_assets().get(f.name)
            if a and exact(a,hs,f.stat().st_size):return a
            if a:
                assert a['state']=='starter' and a['size']==0 and not a['digest'] and mark.read_text()==hs
                gh('api','-X','DELETE',API+'/assets/'+str(a['id']))
            mark.write_text(hs)
            try:helper.upload_assets(TAG,[f],repo=REPO)
            except Exception:
                if i==4:raise
                time.sleep(3**i)
        a=gh_assets()[f.name];assert exact(a,hs,f.stat().st_size);return a
    def verify_part(part):
        f=out/part['name'];assert f.stat().st_size==part['size'];a=upload(f,part['sha256'])
        check_header((a,m['slices'][f.name]))
        # Compare public HTTP range bytes with exact internal offsets from the local verified file.
        with f.open('rb') as src,mmap.mmap(src.fileno(),0,access=mmap.ACCESS_READ) as mm:
            h,it=entries(mm);samples={0,h['addressed_tiles_count']//2,h['addressed_tiles_count']-1};i=0
            for e in it:
                if any(i<=sample<i+e.run_length for sample in samples):
                    off=h['tile_data_offset']+e.offset
                    start,end=off,off+e.length-1
                    for attempt in range(5):
                        try:
                            with requests.get(a['browser_download_url'],params={'asset':a['id'],'offset':off},headers={'Range':f'bytes={start}-{end}'},timeout=(15,60)) as r:
                                r.raise_for_status();assert r.status_code==206 and r.headers['Content-Range']==f'bytes {start}-{end}/{part["size"]}' and r.content==mm[off:off+e.length]
                                break
                        except (AssertionError,requests.RequestException):
                            if attempt==4:raise
                            time.sleep(2**attempt)
                i+=e.run_length
        print('Verified public part and tile ranges',a['name'],a['size'],flush=True)
        return {k:a[k] for k in ('id','name','size','digest','browser_download_url')}
    with ThreadPoolExecutor(2) as pool:published=list(pool.map(verify_part,proof['parts']))
    version=upload(d,proof['descriptor'])
    assert get(version)==d.read_bytes()
    for name in proof['reused']:check_header((live[name],m['slices'][name]))
    for name,path in [(CANON,d),(BOUNDS,SHAPE)]:stage(name,path,gh_assets(),old[name])
    for name,path in [(CANON,d),(BOUNDS,SHAPE)]:swap(name,path,old[name])
    live=gh_assets();aliases={}
    for name,path in [(CANON,d),(BOUNDS,SHAPE)]:
        a=live[name];assert exact(a,filehash(path),path.stat().st_size) and get(a)==path.read_bytes()
        prev=name+'.'+old[name]['digest'][7:19]+'.previous'
        assert live[prev]['id']==old[name]['id'] and live[prev]['digest']==old[name]['digest']
        aliases[name]={k:a[k] for k in ('id','digest','size','browser_download_url')}|{'previous':prev}
    dump(P/'published.json',dict(sheets=3341,added=291,tag=TAG,aliases=aliases,dated_descriptor=version['browser_download_url'],parts=published,reused=proof['reused'],all_tiles=proof['total'],stats=proof['counts'],georef_bounds_sha256=SHAPE_SHA))
    print('Verified the new stable mosaic and the identical georeferenced-release bounds.',flush=True)
if __name__=='__main__':main()
