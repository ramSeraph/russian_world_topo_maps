from collections import Counter,defaultdict
from contextlib import ExitStack
import gzip,hashlib,io,json,math,mmap,os,time
from pathlib import Path
import mercantile
from PIL import Image
from pmtiles import tile as pt,writer as pw
from pmtiles.tile import zxy_to_tileid,tileid_to_zxy,TileType,Compression
from pmtiles_mosaic.partition_common import HEADER_EXPORT_KEYS,SLICE_HEADER_EXPORT_KEYS,convert_header
from align_stripes import align_stripes
from baseline import sha
from render import P, load, save, entries, names
class StableGzip:
    decompress=staticmethod(gzip.decompress)
    @staticmethod
    def compress(data):return gzip.compress(data,mtime=0)
pt.gzip=pw.gzip=StableGzip
def rect(x0,y0,x1,y1,z):
    w,s,_,_=mercantile.bounds(x0,y1,z);_,_,e,n=mercantile.bounds(x1,y0,z)
    return dict(zip(('min_lon_e7','min_lat_e7','max_lon_e7','max_lat_e7'),[round(a*1e7) for a in (w,s,e,n)]))
def footprint(rows,z,zoomonly=False):
    ext=[(x>>(lev-z),y>>(lev-z)) for _,(lev,x,y,_,_) in rows if lev==z or (lev>z and not zoomonly)]
    xs,ys=zip(*ext);return rect(min(xs),min(ys),max(xs),max(ys),z)
def header(zmin,zmax,ext):
    return dict(tile_type=TileType.WEBP,tile_compression=Compression.NONE,min_zoom=zmin,max_zoom=zmax,center_zoom=(zmin+zmax)//2,
                center_lon_e7=(ext['min_lon_e7']+ext['max_lon_e7'])//2,center_lat_e7=(ext['min_lat_e7']+ext['max_lat_e7'])//2,**ext)
def part_groups(rows,low):
    if low:return [list(rows.items())]
    columns=defaultdict(list)
    for tid,r in rows.items():
        z,x,y,n,o=r;columns[x>>(z-14)].append((tid,r))
    groups=[];current=[];cost=0
    for x,b in sorted(columns.items()):
        size=sum(r[3]+24 for _,r in b)
        assert size<1_950_000_000
        if current and cost+size>=1_950_000_000:groups.append(current);current=[];cost=0
        current.extend(b);cost+=size
    if current:groups.append(current)
    return groups
def readrow(mm,tid,r):
    z,x,y,n,off=r
    if off is not None:return mm[off:off+n]
    return (P/'tiles'/str(z)/str(x)/(str(y)+'.webp')).read_bytes()
def use(data):
    assert data[:4]==b'RIFF' and data[8:12]==b'WEBP' and len(data)==int.from_bytes(data[4:8],'little')+8
    with Image.open(io.BytesIO(data)) as im:
        assert im.size==(256,256)
        return 'A' not in im.getbands() or im.getchannel('A').getextrema()[1]>0
def coverage(h,z,x,y):
    if not h['min_zoom']<=z<=h['max_zoom']:return False
    # Equivalent to asking which slice contains the centre of a tiled XYZ cell.
    w=(x+.5)/(1<<z)*360-180
    n=math.degrees(math.atan(math.sinh(math.pi*(1-2*(y+.5)/(1<<z)))))
    return h['min_lon_e7']<=w*1e7<h['max_lon_e7'] and h['min_lat_e7']<n*1e7<=h['max_lat_e7']
def main():
    old=load(P/'old-mosaic.json');meta=load(P/'tiles/metadata.json')
    ready=load(P/'render-ready.json');assert ready['plan']==sha(P/'plan.json') and ready['metadata']==sha(P/'tiles/metadata.json')
    s=P/'export';s.mkdir(exist_ok=True)
    patches=[{},{}];sig=hashlib.sha256();stats=Counter()
    for f in sorted((P/'tiles').glob('*/*/*.webp')):
        z,x,y=int(f.parent.parent.name),int(f.parent.name),int(f.stem);tid=zxy_to_tileid(z,x,y)
        assert z<14 or mercantile.bounds(x,y,z).east<59.48
        b=f.read_bytes();keep=use(b);sig.update(tid.to_bytes(8,'big')+hashlib.sha256(b).digest())
        patches[int(z>=14)][tid]=(z,x,y,len(b),None) if keep else None
    assert sum(map(len,patches))==ready['tiles']
    prefix='Soviet-GS-25k-20261125-'+sig.hexdigest()[:10]
    slices={};files=[];probes={};allkeys=set();levels=Counter()
    for i,name in enumerate(names()):
        reused=i>=2
        path=P/'old'/(name+('.prefix' if reused else ''))
        with path.open('rb') as stream,mmap.mmap(stream.fileno(),0,access=mmap.ACCESS_READ) as mm:
            oh,it=entries(mm);oldcount=0;rows={};zcounts=Counter()
            for e in it:
                off=oh['tile_data_offset']+e.offset
                for tid in range(e.tile_id,e.tile_id+e.run_length):
                    assert tid not in allkeys;allkeys.add(tid);oldcount+=1
                    if not reused:
                        z,x,y=tileid_to_zxy(tid);rows[tid]=(z,x,y,e.length,off)
                    else:
                        z,x,y=tileid_to_zxy(tid);assert coverage(old['slices'][name]['header'],z,x,y)
                        assert tid not in patches[0] and tid not in patches[1];zcounts[z]+=1
            assert oh['addressed_tiles_count']==oldcount;stats['old_tiles']+=oldcount
            if reused:
                slices[name]=old['slices'][name];stats['reused_archive_tiles']+=oldcount;levels.update(zcounts)
                print('Retained',name,oldcount,'tiles',flush=True);continue
            for tid,r in patches[i].items():
                if tid in rows:
                    del rows[tid];stats['old_affected']+=1
                else:
                    assert tid not in allkeys
                if r:rows[tid]=r;stats['patch_tiles']+=1
                else:stats['empty_patch_tiles']+=1
            for items in part_groups(rows,i==0):
                items.sort();zmin=min(r[0] for _,r in items);zmax=max(r[0] for _,r in items)
                actual=header(zmin,zmax,footprint(items,zmax,True));routing=header(zmin,zmax,footprint(items,zmin))
                filename=prefix+f'-part{len(files):04d}.pmtiles';path=s/filename;t=path.with_suffix('.tmp')
                # Reuse the previous bytes for every unaffected tile without a WebP re-encode.
                with t.open('wb') as fp:
                    writer=pw.Writer(fp)
                    for tid,r in items:writer.write_tile(tid,readrow(mm,tid,r))
                    writer.finalize(actual,meta)
                assert t.stat().st_size<2**31;t.replace(path)
                slices[filename]={'header':convert_header(routing,SLICE_HEADER_EXPORT_KEYS)}
                samples={0,len(items)//2,len(items)-1};seen=0
                with path.open('rb') as stream2,mmap.mmap(stream2.fileno(),0,access=mmap.ACCESS_READ) as out:
                    hh,it2=entries(out);assert hh['addressed_tiles_count']==len(items)
                    for e in it2:
                        a=hh['tile_data_offset']+e.offset;buf=out[a:a+e.length]
                        for tid in range(e.tile_id,e.tile_id+e.run_length):
                            wanted,r=items[seen];assert wanted==tid and readrow(mm,tid,r)==buf
                            if r[4] is not None:stats['verified_unchanged_payloads']+=1
                            if seen in samples:probes[f'{r[0]}/{r[1]}/{r[2]}']=hashlib.sha256(buf).hexdigest()
                            seen+=1;levels[r[0]]+=1
                    assert seen==len(items)
                files.append(dict(name=filename,size=path.stat().st_size,sha256=sha(path),tiles=seen))
                print('Verified',filename,seen,'tile payloads',files[-1]['size'],flush=True)
    assert stats['reused_archive_tiles']+stats['verified_unchanged_payloads']==stats['old_tiles']-stats['old_affected']
    total=stats['old_tiles']-stats['old_affected']+stats['patch_tiles'];assert total==sum(levels.values())
    align_stripes(slices,{f["name"] for f in files})
    # Check the descriptor routing of every final coordinate, including every byte-identical retained archive.
    for name,sl in slices.items():
        path=s/name if (s/name).exists() else P/'old'/(name+'.prefix')
        with path.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as mm:
            _,ents=entries(mm)
            for e in ents:
                for tid in range(e.tile_id,e.tile_id+e.run_length):
                    z,x,y=tileid_to_zxy(tid)
                    assert [k for k,v in slices.items() if coverage(v['header'],z,x,y)]==[name],(z,x,y,name)
    # Baltic scans lie within the existing global extent; retain the original map centre and zoom defaults.
    h=old['header']
    for f in load(P/'required.geojson')['features']:
        w,ss,e,n=__import__('shapely').geometry.shape(f['geometry']).bounds
        assert h['min_lon_e7']<=w*1e7<=e*1e7<=h['max_lon_e7'] and h['min_lat_e7']<=ss*1e7<=n*1e7<=h['max_lat_e7']
    m=dict(version=old['version'],metadata=meta,header=h,slices=slices)
    descriptor_name = prefix+'-r2.mosaic.json'
    save(s/descriptor_name,m)
    save(P/'packed.json',dict(parts=files,reused=names()[2:],prefix=prefix,metadata=meta,counts=stats,levels=levels,total=total,probes=probes,old_manifest=sha(P/'old-mosaic.json'),descriptor_name=descriptor_name,descriptor=sha(s/descriptor_name)))
if __name__=='__main__':main()
