import argparse,hashlib,json,io,threading,time,math
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import requests
from PIL import Image
from pmtiles.tile import tileid_to_zxy
from render import P,load,save,entries,names
import mmap
base='https://indianopenmaps.com/world/topo/russian/25k/gs/'
local=threading.local()
def session():
    if not hasattr(local,'s'):local.s=requests.Session()
    return local.s
def sha(b):return hashlib.sha256(b).hexdigest()
def get(url,**kw):
    for i in range(4):
        try:
            r=session().get(url,timeout=(12,40),**kw);r.raise_for_status();return r
        except requests.RequestException:
            if i==3:raise
            time.sleep(2**i)
def xyz(k):
    r=get(base+k+'.webp');b=r.content
    with Image.open(io.BytesIO(b)) as im:assert im.size==(256,256) and im.format=='WEBP'
    return sha(b)
def baseline_probes():
    assets={a['name']:a for a in load(P/'baseline.json')}
    expected={}
    for n in names()[2:]:
        a=assets[n]
        with (P/'old'/(n+'.prefix')).open('rb') as s,mmap.mmap(s.fileno(),0,access=mmap.ACCESS_READ) as mm:
            h,it=entries(mm)
            e=next(e for e in it if e.length>1500 and tileid_to_zxy(e.tile_id)[0]==15)
            off=h['tile_data_offset']+e.offset
            k='/'.join(map(str,tileid_to_zxy(e.tile_id)))
            r=get(a['browser_download_url'],params={'range':off},headers={'Range':f'bytes={off}-{off+e.length-1}'})
            assert r.status_code==206 and len(r.content)==e.length
            expected[k]=sha(r.content)
            assert xyz(k)==expected[k],k
    save(P/'retained-probes.json',expected);print('Verified historical XYZ tiles in each of the three retained parts.',flush=True)
def verify():
    pub=load(P/'published.json');assert pub['sheets']==3341
    plan=load(P/'packed.json');expected=load(P/'public-probes.json')|load(P/'retained-probes.json')
    # Poll the actual stable URL used by normal clients, including any propagation delay in the descriptor cache.
    limit=time.monotonic()+1600
    while True:
        try:
            j=get(base+'tiles.json').json()
            assert j['attribution']==plan['metadata']['attribution'] and j['minzoom']==0 and j['maxzoom']==15 and j['tiles']==[base+'{z}/{x}/{y}.webp']
            break
        except (AssertionError,requests.RequestException,ValueError) as e:
            if time.monotonic()>limit:raise
            print('Waiting for stable TileJSON',type(e).__name__,flush=True);time.sleep(15)
    pending=dict(expected)
    matched={}
    while pending:
        with ThreadPoolExecutor(8) as pool:
            futures={pool.submit(xyz,k):k for k in pending}
            for fu in as_completed(futures):
                k=futures[fu]
                try:
                    if fu.result()==expected[k]:matched[k]=expected[k]
                except (requests.RequestException,OSError,AssertionError):pass
        pending={k:v for k,v in pending.items() if k not in matched}
        print('Verified public XYZ',len(matched),'/',len(expected),flush=True)
        save(P/'live-xyz-progress.json',matched)
        if pending:
            if time.monotonic()>limit:raise RuntimeError(('Public tiles still differ',list(pending)[:10]))
            time.sleep(15)
    save(P/'live-verified.json',dict(tilejson=base+'tiles.json',url_template=j['tiles'][0],tiles=len(matched),checked_sheets=291,retained_archive_examples=load(P/'retained-probes.json'),verified_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())))
if __name__=='__main__':
    import sys
    if sys.argv[1]=='before':baseline_probes()
    else:verify()
