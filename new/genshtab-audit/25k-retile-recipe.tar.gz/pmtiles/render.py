import csv,hashlib,json,mmap,os,shlex,subprocess,time
from pathlib import Path
from collections import Counter
import mercantile
from shapely.geometry import shape
from pmtiles.tile import deserialize_directory,deserialize_header,zxy_to_tileid
from pmtiles_mosaic.tiles_common import MissingTileError
from topo_map_processor.tools import retile
from baseline import sha
P=Path(__file__).resolve().parent
W=P.parent
def load(p):return json.loads(p.read_bytes())
def save(p,v):
    t=p.with_suffix('.tmp');t.write_text(json.dumps(v,indent=2)+'\n');t.replace(p)
def entries(mm):
    h=deserialize_header(mm[:127])
    def walk(start,n):
        for v in deserialize_directory(mm[start:start+n]):
            if v.run_length:yield v
            else:yield from walk(h['leaf_directory_offset']+v.offset,v.length)
    return h,walk(h['root_offset'],h['root_length'])
def names():
    return sorted(load(P/'old-mosaic.json')['slices'])
class Old:
    def __init__(self):
        self.m=load(P/'old-mosaic.json');self.min_zoom=self.m['header']['min_zoom'];self.max_zoom=self.m['header']['max_zoom']
        self.data=None
    def get_metadata(self):return dict(self.m['metadata'])
    def get_tile_data(self,t):
        if self.data is None:
            self.data={};self.mm=[]
            for n in names()[:2]:
                f=P/'old'/n
                until=time.monotonic()+2700
                while not f.is_file():
                    if 'Traceback (most recent call last)' in (P/'baseline.log').read_text() or time.monotonic()>until:raise RuntimeError('Baseline download did not finish')
                    time.sleep(3)
                with f.open('rb') as s:mm=mmap.mmap(s.fileno(),0,access=mmap.ACCESS_READ)
                self.mm.append(mm);h,it=entries(mm)
                for e in it:
                    pos=e.offset+h['tile_data_offset']
                    for i in range(e.tile_id,e.tile_id+e.run_length):self.data[i]=(mm,pos,e.length)
        assert t.z<14 or mercantile.bounds(t).east<59.48,('Unloaded eastern archive',t)
        try:mm,pos,length=self.data[zxy_to_tileid(t.z,t.x,t.y)]
        except KeyError:raise MissingTileError() from None
        return mm[pos:pos+length]
    def cleanup(self):
        if self.data is not None:
            self.data=None
            for mm in self.mm:mm.close()
def prepare():
    with (W/'georef/review/25k-staged-cogs.csv').open() as s:regs={r['sheet']:r for r in csv.DictReader(s)}
    allf=load(W/'publication/ready/georef/bounds.geojson')['features']
    assert len(regs)==291 and len(allf)==3341
    # Keep every sheet whose bounds share even one base XYZ tile with an addition.
    xyz=set();boxes={}
    for f in allf:
        id=f['properties']['id'];box=shape(f['geometry']).bounds;boxes[id]=box
        if id in regs:xyz.update(mercantile.tiles(*box,[15]))
    xs=[t.x for t in xyz];ys=[t.y for t in xyz];x0,x1,y0,y1=min(xs),max(xs),min(ys),max(ys)
    filtered=[];inputs=P/'sources';inputs.mkdir(exist_ok=True)
    published={r['name']:r for r in csv.DictReader((W/'publication/ready/georef/listing_files.csv').open())}
    for f in allf:
        id=f['properties']['id'];box=boxes[id]
        ul=mercantile.tile(box[0],box[3],15);lr=mercantile.tile(box[2],box[1],15)
        if lr.x<x0 or lr.y<y0 or ul.x>x1 or ul.y>y1:continue
        if not any(t in xyz for t in mercantile.tiles(*box,[15])):continue
        filtered.append(f);n=id+'.tif';dest=inputs/n
        if id in regs:
            src=W/'georef/cogs'/n
            assert src.stat().st_size==int(regs[id]['bytes']) and sha(src)==regs[id]['cog_sha256']
            if not dest.exists():dest.symlink_to(src)
        else:
            if not dest.exists():
                tmp=dest.with_suffix('.tmp');subprocess.run(['curl','-fsSL','--retry','4','-o',str(tmp),published[n]['url']],check=True)
                assert sha(tmp)==f['properties']['digest'];tmp.replace(dest)
            assert sha(dest)==f['properties']['digest']
    (P/'sheets.txt').write_text(''.join(n+'.tif\n' for n in sorted(regs)))
    save(P/'required.geojson',dict(type='FeatureCollection',features=filtered))
    required,check=retile.assess_sheet_requirements(P/'sheets.txt',P/'required.geojson',None,15)
    assert check==xyz and required=={f['properties']['id']+'.tif' for f in filtered}
    levels={15:xyz}
    for z in range(14,-1,-1):levels[z]={mercantile.parent(t) for t in levels[z+1]}
    save(P/'plan.json',dict(sheets=len(regs),other_cogs=len(filtered)-len(regs),counts={z:len(v) for z,v in levels.items()},bounds_sha=sha(W/'publication/ready/georef/bounds.geojson'),retile_sha=sha(P/'tool/topo_map_processor/tools/retile.py')))
    print('Plan',load(P/'plan.json'),flush=True)
    return regs,levels
def main():
    os.chdir(P)
    regs,levels=prepare();old=Old()
    retile.create_source_from_paths=lambda paths:old
    original_external=retile.run_external
    def ordered(cmd):
        args=shlex.split(cmd)
        if args[0]=='gdalbuildvrt':
            inputs=sorted(args[2:],key=lambda n:(int(regs.get(Path(n).stem,{}).get('edition',0)),n))
            (P/'vrt-order.txt').write_text('\n'.join(inputs)+'\n')
            subprocess.run(['gdalbuildvrt','-input_file_list',str(P/'vrt-order.txt'),args[1]],check=True)
        else:original_external(cmd)
    retile.run_external=ordered
    try:
        rc=retile.retile_main(['--retile-list-file','sheets.txt','--bounds-file','required.geojson','--from-source','old-mosaic.json','--tiffs-dir','sources','--tiles-dir',str(P/'tiles'),'--num-parallel','10','--batch-size','32','--tile-quality','75'])
        assert rc==0
    finally:old.cleanup()
    for z,expected in levels.items():
        seen={mercantile.Tile(int(f.parent.name),int(f.stem),z) for f in (P/'tiles'/str(z)).glob('*/*.webp')}
        assert seen==expected,(z,len(expected),len(seen))
    meta=load(P/'tiles/metadata.json')
    meta['attribution']+='; <a href="https://archive.org/details/genshtab-latvia-25-k-sk-42">Latvia SK-42</a> and <a href="https://archive.org/details/genshtab-estonia-25-k-saaremaa-hiiumaa-etc">Estonia, Saaremaa and Hiiumaa</a> scans on the Internet Archive'
    save(P/'tiles/metadata.json',meta)
    save(P/'render-ready.json',dict(tiles=sum(map(len,levels.values())),base=len(levels[15]),plan=sha(P/'plan.json'),metadata=sha(P/'tiles/metadata.json')))
if __name__=='__main__':main()
