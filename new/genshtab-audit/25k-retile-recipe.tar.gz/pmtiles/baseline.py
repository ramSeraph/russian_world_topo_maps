import concurrent.futures, hashlib, json, time
from pathlib import Path
import requests
from pmtiles.tile import deserialize_header
P=Path(__file__).resolve().parent
def sha(f):
    with f.open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
def read_file(a,path,needed):
    if path.exists() and ((needed and path.stat().st_size==a['size'] and sha(path)==a['digest'][7:]) or (not needed and path.stat().st_size>127)):
        return
    partial=path.with_suffix('.partial')
    url=a['browser_download_url']
    if not needed:
        for i in range(5):
            try:
                def fetch(end):
                    with requests.get(url,params={'id':a['id'],'end':end},headers={'Range':f'bytes=0-{end}'},timeout=(15,90)) as r:
                        r.raise_for_status();assert r.status_code==206 and r.headers['Content-Range']==f"bytes 0-{end}/{a['size']}"
                        return r.content
                h=deserialize_header(fetch(126));size=h['tile_data_offset'];data=fetch(size-1);assert len(data)==size
                partial.write_bytes(data);partial.replace(path);return
            except Exception:
                if i==4:raise
                time.sleep(2**i)
    for i in range(7):
        if partial.exists() and partial.stat().st_size==a['size']:
            if sha(partial)==a['digest'][7:]:partial.replace(path);return
            partial.unlink()
        off=partial.stat().st_size if partial.exists() else 0
        try:
            with requests.get(url,params={'asset_id':a['id'],'attempt':i},headers={'Range':f'bytes={off}-{a["size"]-1}'},stream=True,timeout=(15,130)) as r:
                r.raise_for_status()
                if off or r.status_code==206:
                    assert r.status_code==206 and r.headers['Content-Range']==f"bytes {off}-{a['size']-1}/{a['size']}"
                with partial.open('ab') as out:
                    for chunk in r.iter_content(1024*1024):out.write(chunk)
            assert partial.stat().st_size==a['size'] and sha(partial)==a['digest'][7:]
            partial.replace(path);return
        except Exception:
            if i==6:raise
            time.sleep(2**i)
def init():
    a={r['name']:r for r in json.loads((P/'baseline.json').read_bytes())}
    m=json.loads((P/'old-mosaic.json').read_bytes())
    assert sha(P/'old-mosaic.json')==a['Soviet-GS-25k.mosaic.json']['digest'][7:] and len(m['slices'])==5
    (P/'old').mkdir(exist_ok=True)
    def fetch(x):
        n,s=x;need=n.endswith(('part0000.pmtiles','part0001.pmtiles'))
        read_file(a[n],P/'old'/(n if need else n+'.prefix'),need);print('Verified baseline' if need else 'Read unchanged directory',n,flush=True)
    with concurrent.futures.ThreadPoolExecutor(4) as pool:list(pool.map(fetch,m['slices'].items()))
    print('Baseline ready.',flush=True)
if __name__=='__main__':init()
