from pathlib import Path
import hashlib,json, subprocess, time, sys, urllib.request
p=Path(__file__).resolve().parent;work=p/'demo-checkout';file='docs/25k/index.html'
repo='ramSeraph/russian_world_topo_maps';tag='25k-gs-pmtiles'
def gh(*args):return subprocess.check_output(['gh',*args],text=True)
def git(*args):return subprocess.check_output(['git','-C',str(work),*args],text=True).strip()
def sha(b):return hashlib.sha256(b).hexdigest()
def get(url):return urllib.request.urlopen(url,timeout=55).read()
pub=json.loads((p/'published.json').read_bytes());bounds=pub['georef_bounds_sha256']
for fam in ('25k-gs-georef',tag):
 r=json.loads(gh('api','repos/'+repo+'/releases/tags/'+fam,'--jq','[.assets[]|select(.name=="bounds.geojson")|{digest,size,id}]'))[0]
 assert r['digest']=='sha256:'+bounds and r['size']==4027041
f=work/file
s=f.read_text();assert 'genshtab-latvia-25-k-sk-42' in s and 'genshtab-estonia-25-k-saaremaa-hiiumaa-etc' in s and './index.geojson' in s
git('fetch','origin','main')
if git('status','--porcelain','--',file):
 assert git('diff','--name-only')==file and not git('diff','--cached','--name-only')
 git('add','--',file);git('diff','--cached','--check');git('commit','-m','Credit the Baltic sources in the 1:25k mosaic demo','--',file)
if subprocess.run(['git','-C',str(work),'merge-base','--is-ancestor','HEAD','origin/main']).returncode:
 git('rebase','origin/main')
 assert git('diff','--name-only','HEAD~1','HEAD')==file
 git('push','origin','HEAD:refs/heads/main')
commit=git('rev-parse','HEAD')
assert git('log','-1','--format=%s')=='Credit the Baltic sources in the 1:25k mosaic demo'
print('Pushed demo',commit,flush=True)
limit=time.monotonic()+900
while True:
 runs=json.loads(gh('run','list','--repo',repo,'--workflow','docs.yml','--commit',commit,'--json','headSha,status,conclusion,url,databaseId'))
 if runs and runs[0]['status']=='completed':
  run=runs[0];assert run['headSha']==commit and run['conclusion']=='success',run;break
 if time.monotonic()>limit:raise TimeoutError('Pages build')
 time.sleep(12)
page='https://ramseraph.github.io/russian_world_topo_maps/25k/'
while True:
 try:
  index=get(page+'index.geojson');html=get(page)
  assert sha(index)==bounds and len(json.loads(index)['features'])==3341 and sha(html)==sha(f.read_bytes())
  break
 except Exception:
  if time.monotonic()>limit:raise
  time.sleep(10)
(p/'pages.json').write_text(json.dumps(dict(page=page,index=page+'index.geojson',bounds_sha256=bounds,count=3341,commit=commit,workflow=run['url']),indent=2)+'\n')
print('Verified live Pages and all 3,341 footprints',page,flush=True)
