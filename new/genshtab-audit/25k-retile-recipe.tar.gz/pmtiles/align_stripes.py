def align_stripes(slices, created):
    """Use one exact E7 longitude at each shared edge of adjacent high-zoom strips."""
    high = sorted((s['header']['min_lon_e7'], name, s['header'])
                  for name, s in slices.items() if s['header']['min_zoom'] == 14)
    for (_, left_name, left), (_, right_name, right) in zip(high, high[1:]):
        delta = left['max_lon_e7'] - right['min_lon_e7']
        if delta <= 0:
            continue
        if delta != 1:
            raise ValueError(f'Overlapping strips: {left_name}, {right_name}')
        if left_name in created:
            left['max_lon_e7'] = right['min_lon_e7']
        elif right_name in created:
            right['min_lon_e7'] = left['max_lon_e7']
        else:
            raise ValueError(f'Overlapping retained strips: {left_name}, {right_name}')
