import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const [dist, file, ...probeFiles] = process.argv.slice(2);
const moduleURL = name => pathToFileURL(resolve(dist, name)).href;
const {MosaicResolver} = await import(moduleURL('resolver.js'));
const {createPartitionAwareIndex} = await import(moduleURL('indexers/partition-aware.js'));
const raw = readFileSync(file);
const resolver = new MosaicResolver(JSON.parse(raw), {createIndex: createPartitionAwareIndex});
for (let z = 0; z <= 15; z++) {
    resolver.resolve(z, Math.floor((2**z)*.564), Math.floor((2**z)*.30));
}
const probes = Object.assign({}, ...probeFiles.map(p => JSON.parse(readFileSync(p))));
for (const tile of Object.keys(probes)) {
    if (!resolver.resolve(...tile.split('/').map(Number)).length) throw Error('No route for '+tile);
}
console.log(JSON.stringify({zooms: [0,15], routes: Object.keys(probes).length, sha256: createHash('sha256').update(raw).digest('hex')}, null, 2));
