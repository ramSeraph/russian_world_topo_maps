from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json,subprocess
scales=['1m','500k','200k','100k','50k','25k'];repo='ramSeraph/russian_world_topo_maps'
def get(key):
 s,t=key;tag=s+'-gs-'+t
 txt=subprocess.check_output(['gh','api','repos/'+repo+'/releases/tags/'+tag,'--jq','[.assets[]|select(.name=="bounds.geojson")|{id,name,digest,size,browser_download_url}]'])
 return key,json.loads(txt)
with ThreadPoolExecutor(4) as pool:rows=dict(pool.map(get,[(s,t) for s in scales for t in ('georef','pmtiles')]))
report={}
for s in scales:
 a=rows[s,'georef'];b=rows[s,'pmtiles']
 report[s]=dict(georef=a,pmtiles=b,identical=bool(a and b and a[0]['digest']==b[0]['digest']))
 print(s,report[s]['identical'],[(x[0]['size'],x[0]['digest'][7:17]) if x else None for x in (a,b)])
Path(__import__('sys').argv[1]).write_text(json.dumps(report,indent=2)+'\n')
