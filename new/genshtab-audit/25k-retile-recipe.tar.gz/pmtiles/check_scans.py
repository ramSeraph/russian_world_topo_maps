"""Compare the Baltic tiles against all source COGs and verify each point in the packed output."""
from pathlib import Path
import csv, io,json,math,mmap
from contextlib import ExitStack
from functools import lru_cache
import numpy as np
from PIL import Image
import rasterio
from rasterio.enums import Resampling
from rasterio.windows import from_bounds
from pyproj import Transformer
from shapely.geometry import shape
import mercantile
from pmtiles.reader import Reader
from pmtiles.tile import zxy_to_tileid
from baseline import sha
import hashlib
P=Path(__file__).resolve().parent;W=P.parent
def load(p):return json.loads(p.read_bytes())
def digest(b):return hashlib.sha256(b).hexdigest()
def at_z(lon,lat,z):
    t=mercantile.tile(lon,lat,z)
    px=round(((lon+180)/360*(1<<z)-t.x)*256-.5)
    py=round(((1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*(1<<z)-t.y)*256-.5)
    return t,(max(0,min(255,px)),max(0,min(255,py)))
def points():
    rows={r['sheet']:r for r in csv.DictReader((W/'georef/review/25k-staged-cogs.csv').open())}
    out={}
    for f in load(W/'georef/review/25k-staged-cogs.geojson')['features']:
        sheet=f['id'];pt=shape(f['geometry']).representative_point();out[sheet]=(sheet,pt.x,pt.y)
    west='O34-095-3-3';joined=west+'_O34-095-3-4'
    # Select a point in the unique eastern strip for the joined sheet and a second in the edition overlap.
    fit=load(W/'fitted'/(joined+'.json'))['control'];to_wgs=Transformer.from_crs(fit['native_geographic_crs'],4326,always_xy=True)
    out[joined]=(joined,*to_wgs.transform(23+8.3/60,57+22.2/60))
    out['Mersrags-overlap-1962']=(west,*to_wgs.transform(23+4.3/60,57+22.2/60))
    assert len(rows)==291 and len(out)==292
    return out
def main():
    probes={};public={};meta=load(P/'packed.json');desc=load(P/'export'/(meta['prefix']+'.mosaic.json'))
    files={r['name']:r for r in meta['parts']}
    with ExitStack() as stack:
        readers={}
        for name in files:
            src=stack.enter_context((P/'export'/name).open('rb'));mm=stack.enter_context(mmap.mmap(src.fileno(),0,access=mmap.ACCESS_READ))
            readers[name]=Reader(lambda off,n,m=mm:m[off:off+n])
        def read_tile(t):
            w,s,e,n=mercantile.bounds(t);lon=(w+e)/2;lat=(s+n)/2
            cand=[name for name,sl in desc['slices'].items() if (h:=sl['header']) and h['min_zoom']<=t.z<=h['max_zoom'] and h['min_lon_e7']<lon*1e7<h['max_lon_e7'] and h['min_lat_e7']<lat*1e7<h['max_lat_e7']]
            assert len(cand)==1 and cand[0] in readers,(t,cand)
            return readers[cand[0]].get(t.z,t.x,t.y)
        for key,(sheet,lon,lat) in points().items():
            t,(x,y)=at_z(lon,lat,15)
            b=read_tile(t)
            assert b==(P/'tiles'/str(t.z)/str(t.x)/(str(t.y)+'.webp')).read_bytes()
            with Image.open(io.BytesIO(b)) as img:rgba=np.asarray(img.convert('RGBA'))
            with rasterio.open(W/'georef/cogs'/(sheet+'.tif')) as ds:
                win=from_bounds(*mercantile.xy_bounds(t),ds.transform)
                ref=ds.read(window=win,out_shape=(3,256,256),resampling=Resampling.lanczos,boundless=True)
                mask=ds.read_masks(1,window=win,out_shape=(256,256),resampling=Resampling.nearest,boundless=True)
            a,bx=max(0,x-48),min(256,x+49);c,d=max(0,y-48),min(256,y+49)
            alpha=rgba[c:d,a:bx,3];good=(alpha>220)&(mask[c:d,a:bx]>220)
            assert good.mean()>.97 and rgba[y,x,3]>220,(key,good.mean(),rgba[y,x])
            scan=np.moveaxis(ref,0,-1)[c:d,a:bx].astype(float)
            tile=rgba[c:d,a:bx,:3].astype(float)
            mae=float(np.abs(scan[good]-tile[good]).mean())
            blur=lambda img:np.array(Image.fromarray(img.astype('uint8')).resize((12,12),Image.Resampling.BOX)).astype(float)
            blockmae=float(np.abs(blur(scan)-blur(tile)).mean())
            k=f'{t.z}/{t.x}/{t.y}'
            probes[key]=dict(sheet=sheet,xyz=k,sha256=digest(read_tile(t)),pixel=[x,y],mean_rgb_error=round(mae,3),block_rgb_error=round(blockmae,3))
            public[k]=probes[key]['sha256']
        # Exercise changed overviews, including the global overview.
        for z in (0,3,6,9,12,14):
            t,_=at_z(23.09,57.37,z);raw=read_tile(t);assert raw
            public[f'{z}/{t.x}/{t.y}']=digest(raw)
    (P/'pixel-checks.json').write_text(json.dumps(probes,indent=2))
    errors=sorted(probes.items(),key=lambda x:x[1]['block_rgb_error'],reverse=True)
    print('Largest input comparison errors',[(k,r['mean_rgb_error'],r['block_rgb_error']) for k,r in errors[:5]],flush=True)
    assert max(r['mean_rgb_error'] for _,r in errors)<27 and errors[0][1]['block_rgb_error']<10
    public.update(meta['probes'])
    (P/'public-probes.json').write_text(json.dumps(public,indent=2))
    print('Checked every new scan and the joined-sheet overlap:',len(probes),'comparisons.',flush=True)
if __name__=='__main__':main()
