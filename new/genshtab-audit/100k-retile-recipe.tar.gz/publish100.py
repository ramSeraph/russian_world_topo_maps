"""Stage dated PMTiles, sample public byte ranges, and release their dated descriptor after verification."""
import hashlib
import json
import subprocess
import time
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
import requests
from pmtiles.reader import Reader
from pmtiles.tile import deserialize_header
from release_tools import upload_to_release as helper
from archives100 import Ranges,digest,records,write_json

TAG='100k-gs-pmtiles'
REPO='ramSeraph/russian_world_topo_maps'
API='repos/'+REPO+'/releases'
CANON='Soviet-GS-100k.mosaic.json'
def utc():return datetime.now(timezone.utc).isoformat()
def gh(*args):
    for i in range(8):
        proc=subprocess.run(['gh',*args],capture_output=True)
        if proc.returncode==0:return proc.stdout
        msg=proc.stderr.decode(errors='replace');print('GitHub read retry',i+1,msg[-350:],flush=True)
        if 'rate limit' in msg.lower():
            q=json.loads(subprocess.check_output(['gh','api','rate_limit']))['resources']['core'];time.sleep(max(120,int(q['reset']-time.time())+15))
        else:time.sleep(min(60,2**i))
    raise RuntimeError(msg)
def live():
    return {a['name']:a for a in json.loads(gh('api',API+'/tags/'+TAG,'--jq','[.assets[]|{name,size,id,state,digest,browser_download_url,created_at}]'))}
def uploaded(a,n,sha):
    assert a['state']=='uploaded' and a['size']==n and a['digest']=='sha256:'+sha,a
    return {k:a[k] for k in ('name','size','id','created_at','browser_download_url')}|{'sha256':sha,'url':a['browser_download_url']}
_verified_job_snapshots=set()
def validate_render_sources(root):
    info=json.loads((root/'patch-ready.json').read_bytes())
    ident=info['identity'];plan=json.loads((root/'plan.json').read_bytes())
    assert ident==json.loads((root/'render-identity.json').read_bytes()) and ident['zoom']==13 and ident['tile_quality']==75
    for n in ('plan.json','old-mosaic.json','sources.json','affected-bounds.geojson','retile-sheets.txt','affected-base.xyz','topo_map_processor/tools/retile.py'):
        assert ident[n]==digest(root/n),('Signed rendering input changed',n)
    assert info['affected_base_file']=='affected-base.xyz' and info['metadata_sha256']==digest(root/'tiles/metadata.json') and info['levels']==plan['levels']
    assert info['sources']==json.loads((root/'sources-ready.json').read_bytes()) and info['sources']['source_register_sha256']==ident['sources.json']
    assert info['sources']['verified']==plan['required_cogs']==3233
def upload(file,sha,state):
    if state not in _verified_job_snapshots:
        validate_render_sources(state.parent)
        _verified_job_snapshots.add(state)
    n=file.stat().st_size;assert digest(file)==sha and 0<n<2**31
    attempts=state/'upload-attempts';attempts.mkdir(exist_ok=True)
    own=attempts/(file.name+'.json')
    failures=0
    while failures<8:
        a=live().get(file.name)
        if a:
            if a['state']=='uploaded':return uploaded(a,n,sha)
            assert a['state']=='starter' and a['size']==0 and not a['digest'] and own.is_file(),a
            assert json.loads(own.read_bytes())=={'sha256':sha,'size':n}
            # GitHub documents zero-byte starter placeholders from failed upload attempts.
            gh('api','--method','DELETE',API+'/assets/'+str(a['id']))
        write_json(own,{'sha256':sha,'size':n})
        try:helper.upload_assets(TAG,[file],repo=REPO)
        except Exception as err:
            text=str(getattr(err.__context__,'stderr','') or '')+' '+str(err)
            if 'rate limit' in text.lower():
                q=json.loads(gh('api','rate_limit'))['resources']['core'];time.sleep(max(120,int(q['reset']-time.time())+15));continue
            failures+=1;print('Upload retry',file.name,failures,text[-240:],flush=True)
            time.sleep(min(75,2**failures))
    a=live().get(file.name)
    if a:return uploaded(a,n,sha)
    raise RuntimeError(('Eight unsuccessful upload attempts',file.name))
def remote_range_probes(a,info):
    req=Ranges(a)
    try:
        hdr=req.read(0,127);head=deserialize_header(hdr)
        assert head['addressed_tiles_count']==info['tiles']
        p=hdr+req.read(127,head['tile_data_offset']-127)
        def read(off,n):
            if off+n<=len(p):return p[off:off+n]
            return req.read(off,n)
        reader=Reader(read)
        for s in info['probes']:
            v=reader.get(s['z'],s['x'],s['y']);assert v and hashlib.sha256(v).hexdigest()==s['sha256'],s
    finally:req.close()

def verify_disjoint(parts):
    for j,a in enumerate(parts):
        x=a['header']
        for b in parts[j+1:]:
            y=b['header']
            if max(x['min_zoom'],y['min_zoom'])>min(x['max_zoom'],y['max_zoom']):continue
            east=min(x['max_lon_e7'],y['max_lon_e7']);west=max(x['min_lon_e7'],y['min_lon_e7'])
            north=min(x['max_lat_e7'],y['max_lat_e7']);south=max(x['min_lat_e7'],y['min_lat_e7'])
            assert east<=west+1 or north<=south+1,('Overlapping scoped ranges',a['name'],b['name'],x,y)

def finish(root,patch,meta,groups,refs,prefix):
    from pack100 import header
    from pmtiles_mosaic.partition_common import HEADER_EXPORT_KEYS,convert_header
    validate_render_sources(root)
    p=root/'pack';old,baseline=records(root)
    assert len(groups)==len(baseline)==22 and all(g['references']==refs and g['group']==i and g['old']==baseline[i]['name'] for i,g in enumerate(groups))
    for k,h in refs.items():assert digest(root/k)==h,(k,'input changed after staging')
    parts=[f for g in groups for f in g['files']]
    assert len({f['name'] for f in parts})==len(parts)==len({f['id'] for f in parts})
    assert [f['name'] for f in parts]==[prefix+f'-part{i:04}.pmtiles' for i in range(len(parts))]
    verify_disjoint(parts)
    stats=Counter();outs=Counter();olds=Counter();samples={k:{} for k in ('independent','centres','restored')}
    for g in groups:
        stats.update(g['stats']);outs.update({int(k):v for k,v in g['outlevels'].items()});olds.update({int(k):v for k,v in g['oldlevels'].items()})
        for k in samples:
            assert not(set(samples[k])&set(g['samples'][k]));samples[k].update(g['samples'][k])
    ready=json.loads((root/'old-dirs/ready.json').read_bytes())
    cache=json.loads((root/'old-dirs/cache-ready.json').read_bytes())
    footprint=json.loads((root/'old-dirs/old-affected.json').read_bytes())
    assert footprint['base_sha256']==patch['base_sha256'] and stats['old_affected']==footprint['old_inside_patch'] and stats['untouched_tiles']==footprint['old_outside_patch']

    assert stats['old']==ready['count']==3_214_412 and stats['verified_cached_contents']==cache['requested_unique_content_count']
    assert stats['output_tiles']==sum(outs.values())==sum(f['tiles'] for f in parts)==stats['patch_tiles']+stats['untouched_tiles']
    assert stats['patch_tiles']+stats['tombstones']==sum(patch['levels'].values()) and stats['tombstones']==sum(patch['empty'].values())
    assert len(samples['centres'])==2692 and len(samples['restored'])==3
    expected=json.loads((root/'probe-points.json').read_bytes())
    assert set(expected)==set(samples['independent']) and len(expected)==2732
    by={a['name']:a for a in parts}
    for key,out in samples['independent'].items():
        assert all(expected[key][k]==out[k] for k in ('tile','pixel'))
        if out['part']:assert out['part'] in by and len(out['sha256'])==64
        else:assert out['sha256'] is out['rgba'] is None
    states=live()
    for orig in baseline:
        actual=states[orig['name']];assert orig['id']==actual['id'] and orig['digest']==actual['digest'] and orig['size']==actual['size']
    assert states[CANON]['digest']=='sha256:'+refs['old-mosaic.json']
    for a in parts:
        data=uploaded(states[a['name']],a['size'],a['sha256']);assert data['id']==a['id'] and data['url']==a['url']
    top=max(outs);hi=[f['pmtiles_header'] for f in parts if f['pmtiles_header']['max_zoom']==top]
    ext={k:(min if k.startswith('min') else max)(h[k] for h in hi) for k in ('min_lon_e7','min_lat_e7','max_lon_e7','max_lat_e7')}
    m={'version':1,'metadata':meta,'header':convert_header(header(min(outs),top,ext),HEADER_EXPORT_KEYS),'slices':{f['name']:{'header':f['header']} for f in parts}}
    assert top==13 and min(outs)==0 and m['header']['min_lat_e7']<old['header']['min_lat_e7']
    name=prefix+'.mosaic.json';private=p/'deployment';private.mkdir(exist_ok=True)
    descriptor=private/name;write_json(descriptor,m)
    (private/CANON).write_bytes(descriptor.read_bytes())
    for filename,k in [('centres.json','centres'),('restored-centres.json','restored'),('independent-expected.json','independent')]:write_json(private/filename,samples[k])
    write_json(private/'pack-verification.json',{'references':refs,'old_header':old['header'],'header':m['header'],'stats':stats,'previous_coverage_at_affected_tiles':footprint,'patch':patch,'old_levels':olds,'output_levels':outs,'parts':parts,'verified_original_asset_count':len(baseline),'all_full_input_bytes':sum(a['size'] for a in baseline),'all_output_bytes':sum(a['size'] for a in parts),'independent_points':len(expected),'component_centres':len(samples['centres']),'restorations':len(samples['restored']),'verified_utc':utc()})
    desc=upload(descriptor,digest(descriptor),p)
    raw=gh('api',API+'/assets/'+str(desc['id']),'-H','Accept: application/octet-stream')
    assert raw==descriptor.read_bytes()
    for attempt in range(6):
        try:
            resp=requests.get(desc['url'],params={'asset':desc['id']},timeout=(15,45));resp.raise_for_status();assert resp.content==raw;break
        except (requests.RequestException,AssertionError):
            if attempt==5:raise
            time.sleep(2**attempt)
    slim={f['name']:{k:f[k] for k in ('name','id','url','size','sha256','header','pmtiles_header')} for f in parts}
    report={'tag':TAG,'canonical':CANON,'descriptor':desc,'parts':slim,'patch_receipt_sha256':refs['patch-ready.json'],'baseline_mosaic_sha256':refs['old-mosaic.json'],'levels':patch['levels'],'output_levels':outs,'output_tiles':stats['output_tiles'],'untouched_tiles':stats['untouched_tiles'],'patch_tiles':stats['patch_tiles'],'tombstones':stats['tombstones'],'probes':[s for f in parts for s in f['probes']],'verified_utc':utc()}
    write_json(private/'dated-assets-published.json',report)
    names=[name,CANON,'centres.json','restored-centres.json','independent-expected.json','pack-verification.json','dated-assets-published.json']
    bundle=p/'package-done.tar.gz'
    subprocess.run(['tar','-czf',str(bundle.with_suffix('.partial')),'-C',str(private),*names],check=True);bundle.with_suffix('.partial').replace(bundle)
    print('All dated release assets and descriptor signed off',len(parts),'parts,',stats['output_tiles'],'tiles;',bundle,flush=True)
