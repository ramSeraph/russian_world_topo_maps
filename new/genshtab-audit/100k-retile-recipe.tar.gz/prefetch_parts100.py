"""Keep the next old source stripe ready while one is verified, written and uploaded."""
from pathlib import Path
import shutil
import time
from archives100 import records
from full_old100 import WORK,full
root=Path.cwd()
_,assets=records(root)
prefetched=set()
while True:
    done={j for j in range(len(assets)) if (root/'pack/groups'/f'{j:02}.json').exists()}
    if len(done)==len(assets):break
    g=min(set(range(len(assets)))-done)
    for i in range(g,min(g+2,len(assets))):
        if i not in prefetched and i not in done:
            while shutil.disk_usage(WORK).free<10_000_000_000:time.sleep(20)
            full(root,assets[i]);prefetched.add(i)
    time.sleep(15)
