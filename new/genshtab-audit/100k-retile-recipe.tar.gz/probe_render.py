"""Compare actual WebP pixels at separated new-sheet centres with the released COGs."""
from pathlib import Path
import json, math, sys, time
import mercantile
import numpy as np
from PIL import Image, ImageDraw
import cv2
from osgeo import gdal
gdal.UseExceptions()
p=Path.cwd(); c=json.loads((p/'centres-input.json').read_bytes())
limit=int(sys.argv[1]) if len(sys.argv)>1 else 24
zoom=13; side=1<<zoom
period=math.pi*6378137
results=[]
candidates=[]
for sheet,pts in c.items():
    for cell,(lon,lat) in pts.items():
        t=mercantile.tile(lon,lat,zoom)
        img=p/'tiles'/str(zoom)/str(t.x)/(str(t.y)+'.webp')
        if img.exists():
            candidates.append((cell,sheet,lon,lat,t,img))
candidates.sort()
idx=np.linspace(0,len(candidates)-1,min(len(candidates),limit),dtype=int)
for i in idx:
    cell,sheet,lon,lat,t,img=candidates[i]
    cx=round(((lon+180)/360*side-t.x)*256-.5)
    cy=round(((1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*side-t.y)*256-.5)
    b=mercantile.xy_bounds(t)
    ds=gdal.Warp('',str(p/'sources'/(sheet+'.tif')),format='MEM',dstSRS='EPSG:3857',outputBounds=(b.left,b.bottom,b.right,b.top),width=256,height=256,resampleAlg='lanczos',dstAlpha=True)
    ref=ds.ReadAsArray().transpose(1,2,0);ds=None
    with Image.open(img) as im: image=np.array(im.convert('RGBA'))
    sy=slice(max(0,cy-25),min(256,cy+26));sx=slice(max(0,cx-25),min(256,cx+26))
    if ref[cy,cx,3]==0:raise RuntimeError((sheet,'source mask is empty at selected sample'))
    assert image[cy,cx,3]>0,(sheet,'rendered centre is empty')
    a=ref[sy,sx];d=image[sy,sx];mask=(a[:,:,3]>240)&(d[:,:,3]>240)
    err=float(np.abs(a[:,:,:3][mask].astype(float)-d[:,:,:3][mask].astype(float)).mean())
    y1=a[:,:,:3][mask].mean(axis=-1);y2=d[:,:,:3][mask].mean(axis=-1)
    corr=float(np.corrcoef(y1,y2)[0,1]) if min(y1.std(),y2.std())>3 else None
    results.append({'sheet':sheet,'cell':cell,'xyz':[zoom,t.x,t.y],'pixels':int(mask.sum()),'mean_rgb_difference':round(err,2),'luminance_correlation':None if corr is None else round(corr,3)})
    gray1=cv2.cvtColor(ref[:,:,:3],cv2.COLOR_RGB2GRAY)
    gray2=cv2.cvtColor(image[:,:,:3],cv2.COLOR_RGB2GRAY)
    yy=min(208,max(48,cy));xx=min(208,max(48,cx))
    patch=gray1[yy-28:yy+29,xx-28:xx+29];area=gray2[yy-44:yy+45,xx-44:xx+45]
    matches=cv2.matchTemplate(area,patch,cv2.TM_CCOEFF_NORMED)
    _,best,_,pos=cv2.minMaxLoc(matches)
    smooth1=cv2.GaussianBlur(gray1,(9,9),1.7)[sy,sx][mask]
    smooth2=cv2.GaussianBlur(gray2,(9,9),1.7)[sy,sx][mask]
    smoothcorr=round(float(np.corrcoef(smooth1,smooth2)[0,1]),3) if min(smooth1.std(),smooth2.std())>2 else None
    results[-1].update(best_shift=[pos[0]-16,pos[1]-16],best_corr=round(best,3),smoothed_correlation=smoothcorr)
    if err>30 or corr is not None and corr<.7:
        panel=Image.new('RGB',(512,284),'white');panel.paste(Image.fromarray(ref[:,:,:3]),(0,24));panel.paste(Image.fromarray(image[:,:,:3]),(256,24));draw=ImageDraw.Draw(panel);draw.text((4,3),cell+' released COG',fill='black');draw.text((260,3),cell+' retile',fill='black')
        (p/'sample-diagnostics').mkdir(exist_ok=True);panel.save(p/'sample-diagnostics'/(cell+'.jpg'),quality=94)
out={'sample_count':len(results),'available_at_check':len(candidates),'results':results}
(p/('render-cog-samples-'+str(limit)+'.json')).write_text(json.dumps(out,indent=2)+'\n')
print('Compared',len(results),'independent rendered-tile/COG source windows from',len(candidates),'currently rendered sheet centres.',flush=True)
