"""Track durable GDAL progress and resume an interrupted render from its committed batches."""
from pathlib import Path
import fcntl
import json
import os
import re
import shutil
import subprocess
import time

job=Path(__file__).resolve().parent
os.chdir(job)
guard=(job/'monitor.lock').open('a')
fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
log=job/'render-resume.log'
start=time.time()
last=0
report={'stage':'rendering','base_tiles':0,'total_base_tiles':394630,'restarts':0}
def save(status):
    report.update(stage=status,utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),free_gib=round(shutil.disk_usage(job).free/1024**3,1))
    tmp=job/'render-status.tmp'
    tmp.write_text(json.dumps(report,indent=2)+'\n')
    tmp.replace(job/'render-status.json')
def alive():
    proc=Path('/proc')/(job/'render.pid').read_text().strip()
    return proc.exists() and (proc/'cwd').is_symlink() and (proc/'cwd').resolve()==job and b'render_patch.py' in (proc/'cmdline').read_bytes()
while not (job/'patch-ready.json').exists():
    if log.exists():
        with log.open('rb') as f:
            f.seek(max(0,log.stat().st_size-24576));tail=f.read().decode('utf-8','replace')
        m=re.findall(r'Completed base batch (\d+)/(\d+) \((\d+)/(\d+) tiles\)',tail)
        if m and report['restarts']==0:
            report.update(completed_batch=int(m[-1][0]),batches=int(m[-1][1]),base_tiles=int(m[-1][2]))
        if 'handling level' in tail:
            report['overview_zoom']=int(re.findall(r'handling level (\d+)',tail)[-1])
            report['base_tiles']=report['total_base_tiles']
    if not alive():
        if (job/'patch-ready.json').is_file():break
        if 'AssertionError' in tail or 'RuntimeError' in tail or report['restarts']>=3:
            save('renderer requires inspection');raise SystemExit(tail[-1300:])
        if shutil.disk_usage(job).free<10*1024**3:
            save('waiting for disk space');time.sleep(55);continue
        report['restarts']+=1
        log=job/('render-recovery-'+str(int(time.time()))+'.log')
        with log.open('wb') as out:
            proc=subprocess.Popen(['bash','start.sh'],stdout=out,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
        (job/'render.pid').write_text(str(proc.pid)+'\n')
        report['log']=log.name
    save('rendering' if 'overview_zoom' not in report else 'building overviews')
    time.sleep(55)
save('patch verified')
env=dict(os.environ,PYTHONPATH=str(job)+':/usr/lib/python3/dist-packages',OPENBLAS_NUM_THREADS='1')
subprocess.run(['nice','-n','8','python3','probe_render.py','320'],env=env,check=True)
save('pixel comparison complete')
