"""Fetch one digest-pinned released original shard in bounded reusable workspace."""
import fcntl
import hashlib
import os
import shutil
import subprocess
import time
from pathlib import Path
from archives100 import records,digest,write_json

WORK=Path(os.environ.get('RWT_TILE_WORK',Path.home()/'rwt-100k-retile-working-20261122'))

def full(root,asset):
    store=WORK/'baseline';store.mkdir(exist_ok=True,parents=True)
    target=store/asset['name'];tmp=target.with_suffix('.partial')
    with (store/(target.name+'.lock')).open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        if target.is_file() and target.stat().st_size==asset['size'] and 'sha256:'+digest(target)==asset['digest']:return target
        assert shutil.disk_usage(store).free>asset['size']+3_000_000_000
        for attempt in range(5):
            if tmp.exists() and tmp.stat().st_size>=asset['size']:
                if tmp.stat().st_size==asset['size'] and 'sha256:'+digest(tmp)==asset['digest']:break
                tmp.unlink()
            url=asset['browser_download_url']+f"?source-asset={asset['id']}&revision=20261122-{attempt}"
            subprocess.run(['curl','-4','--fail','--location','--silent','--show-error','--continue-at','-','--retry','6','--retry-all-errors','--retry-delay','3','--connect-timeout','18','--speed-time','75','--speed-limit','18000','--output',str(tmp),url],check=False)
            if tmp.is_file() and tmp.stat().st_size==asset['size'] and 'sha256:'+digest(tmp)==asset['digest']:break
            time.sleep(2**attempt)
        else:raise RuntimeError(('Incomplete original',asset['name']))
        checked_prefix=(root/'old-dirs'/(asset['name']+'.prefix')).read_bytes()
        with tmp.open('rb') as stream:assert stream.read(len(checked_prefix))==checked_prefix
        tmp.replace(target)
        print('Verified complete old asset',target.name,asset['size'],asset['digest'],flush=True)
        return target
if __name__=='__main__':
    import sys
    root=Path.cwd();_,assets=records(root)
    for num in sys.argv[1:]:full(root,assets[int(num)])
