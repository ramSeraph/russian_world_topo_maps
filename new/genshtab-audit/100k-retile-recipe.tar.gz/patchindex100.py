"""Register the entire signed-off retile pyramid and the prev/out routing of every patched tile."""
import bisect
import hashlib
import io
import json
import sqlite3
import time
from collections import Counter
from pathlib import Path
from PIL import Image
from pmtiles.tile import zxy_to_tileid
from archives100 import records,digest,write_json

def boundaries(manifest):
    hs=[v['header'] for k,v in sorted(manifest['slices'].items())]
    assert hs[0]['min_zoom']==0 and hs[0]['max_zoom']==10
    assert all(h['min_zoom']==11 and h['max_zoom']==13 for h in hs[1:])
    edges=[round((h['max_lon_e7']/1e7+180)*2048/360) for h in hs[1:]]
    assert edges[-1]==2048 and edges==sorted(set(edges))
    for j,h in enumerate(hs[1:]):
        assert round((h['min_lon_e7']/1e7+180)*2048/360)==(edges[j-1] if j else 0)
    return edges

def groupof(z,x,edges):
    return 0 if z<=10 else 1+bisect.bisect_right(edges,x>>(z-11))

def truth(data):
    assert data[:4]==b'RIFF' and data[8:12]==b'WEBP' and int.from_bytes(data[4:8],'little')+8==len(data)
    with Image.open(io.BytesIO(data),formats=['WEBP']) as im:
        assert im.size==(256,256)
        return 'A' not in im.getbands() or im.getchannel('A').getextrema()[1]!=0

def build(root):
    rec=root/'patch-ready.json';info=json.loads(rec.read_bytes())
    plan=json.loads((root/'plan.json').read_bytes())
    assert info['base_zoom']==plan['base_zoom']==13 and info['levels']==plan['levels']
    srcsha=digest(rec);base_sha=digest(root/'affected-base.xyz');manifest,assets=records(root);edges=boundaries(manifest)
    stage=root/'pack';stage.mkdir(exist_ok=True)
    ready=stage/'patch-index.json';dbfile=stage/'patch.sqlite'
    if ready.is_file() and dbfile.is_file():
        r=json.loads(ready.read_bytes())
        assert r['patch_ready_sha256']==srcsha and r['base_sha256']==base_sha and r['database_sha256']==digest(dbfile)
        return r
    expected=set()
    for line in (root/'affected-base.xyz').read_text().splitlines():
        z,x,y=map(int,line.split());assert z==13 and (x,y) not in expected;expected.add((x,y))
    tmp=stage/'patch.partial.sqlite';tmp.unlink(missing_ok=True)
    con=sqlite3.connect(tmp)
    con.execute('create table patch(tid integer primary key,g integer not null,z integer not null,x integer not null,y integer not null,n integer not null,h blob not null,keep integer not null)')
    counts=Counter();empty=Counter();h=hashlib.sha256();totalbytes=0
    for z in range(13,-1,-1):
        want=expected
        assert len(want)==info['levels'][str(z)]
        rows=[];seen=set()
        for f in (root/'tiles'/str(z)).glob('*/*.webp'):
            x=int(f.parent.name);y=int(f.stem);assert (x,y) in want and (x,y) not in seen
            tid=zxy_to_tileid(z,x,y);raw=f.read_bytes();data_sha=hashlib.sha256(raw).digest();keep=truth(raw)
            rows.append((tid,groupof(z,x,edges),z,x,y,len(raw),data_sha,int(keep)));seen.add((x,y));totalbytes+=len(raw)
            counts[z]+=1
            if not keep:empty[z]+=1
        if seen!=want:raise RuntimeError(('Incomplete patch',z,len(want-seen),len(seen-want),list(want-seen)[:7]))
        rows.sort()
        for t,g,z,x,y,n,src,keep in rows:h.update(t.to_bytes(8,'big')+src+bytes([keep]))
        con.executemany('insert into patch values(?,?,?,?,?,?,?,?)',rows);con.commit()
        print('Verified patch level',z,len(rows),'transparent',empty[z],flush=True)
        expected={(x//2,y//2) for x,y in want}
    assert counts=={int(k):v for k,v in info['levels'].items()}
    con.execute('create index patch_group on patch(g)');con.commit();con.close();tmp.replace(dbfile)
    out={'patch_ready_sha256':srcsha,'metadata_sha256':digest(root/'tiles/metadata.json'),'base_sha256':base_sha,'patch_content_sha256':h.hexdigest(),'database_sha256':digest(dbfile),'levels':counts,'empty':empty,'patch_bytes':totalbytes}
    write_json(ready,out);return out
