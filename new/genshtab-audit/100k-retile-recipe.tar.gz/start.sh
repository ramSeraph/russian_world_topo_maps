#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
export PYTHONPATH="$PWD:/usr/lib/python3/dist-packages"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 GDAL_PAM_ENABLED=NO GDAL_NUM_THREADS=1
exec nice -n 2 python3 -u render_patch.py
