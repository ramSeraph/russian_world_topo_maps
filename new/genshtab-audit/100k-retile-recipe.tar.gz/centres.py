"""Select a real interior point per acquisition cell from the released partial and joined extents."""
import csv
import json
from pathlib import Path
import sys
from shapely.geometry import shape

job=Path(__file__).resolve().parent
audit=Path(sys.argv[1])
features=json.loads((audit/'coverage/100k.geojson').read_bytes())['features']
live=json.loads(Path(sys.argv[2]).read_bytes())['features']
polygons={f['properties']['id']:shape(f['geometry']) for f in live}
result={}
for f in features:
    props=f['properties']
    if props['coverage_status']!='added':
        continue
    sid=props['scan_id']
    cell=props['id']
    actual=polygons[sid].intersection(shape(f['geometry']))
    assert not actual.is_empty and actual.area>0, (sid,cell)
    point=actual.centroid
    if not actual.contains(point):
        point=actual.representative_point()
    result.setdefault(sid,{})[cell]=[point.x,point.y]
assert len(result)==2667 and sum(map(len,result.values()))==2692
(job/'centres-input.json').write_text(json.dumps(result,separators=(',',':')))
restored=json.loads((job/'plan.json').read_bytes())['restored']
(job/'restored-centres.json').write_text(json.dumps({s:list(polygons[s].representative_point().coords[0]) for s in restored}))
