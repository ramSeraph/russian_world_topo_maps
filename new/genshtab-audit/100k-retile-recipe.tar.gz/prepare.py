"""Plan the 1:100k published-coverage update against the released COGs and original PMTiles."""
import csv
import hashlib
import json
from pathlib import Path
import sys

import mercantile
from shapely.geometry import shape

job = Path(__file__).resolve().parent
workspace = Path(sys.argv[1])
metadata = Path(sys.argv[2])
previous_releases = Path(sys.argv[3])
released = metadata / 'final/bounds.geojson'
bounds = json.loads(released.read_bytes())
verification = json.loads((metadata/'final/verification.json').read_bytes())
assert hashlib.sha256(released.read_bytes()).hexdigest() == verification['bounds_sha256']
assert len(bounds['features']) == 15639
original_mosaic = job.parent/'manifest-check.json'
assert hashlib.sha256(original_mosaic.read_bytes()).hexdigest() == '067feeb8275055c103371302f18cacc2ec0553cfaa1a42778e9c53494675899a'
base_zoom = json.loads(original_mosaic.read_bytes())['header']['max_zoom']
assert base_zoom == 13
with (workspace/'new/genshtab-audit/100k-staged-cogs.csv').open() as stream:
    new = {r['id']:r for r in csv.DictReader(stream)}
assert len(new)==2667
snapshot = json.loads((previous_releases/'before/snapshot.json').read_bytes())
assets = {a['name']:a for tag,rows in snapshot.items() if '-georef' in tag for a in rows if a['name'].endswith('.tif')}
for a in json.loads((metadata/'public-assets.json').read_bytes()):
    if a['name'].endswith('.tif'):
        assets[a['name']] = a
features = {f['properties']['id']:f for f in bounds['features']}
assert len(assets)==len(features) and set(assets)=={n+'.tif' for n in features}
restored = set(verification['fallbacks_restored_to_bounds'])
updated = new.keys() | restored
assert len(updated)==2670
masks = verification['legacy_empty_cog_masks']
assert not (updated & masks.keys())
def write_json(name,data):
    (job/name).write_text(json.dumps(data,separators=(',',':'))+'\n')
def listings(name,items):
    (job/name).write_text(''.join(str(x)+'\n' for x in sorted(items)))
def tile_keys(sid):
    west,south,east,north = extents[sid]
    return ((t.x<<base_zoom) | t.y for t in mercantile.tiles(west,south,east,north,[base_zoom]))
extents = {n:shape(f['geometry']).bounds for n,f in features.items()}
tiles=set()
for sid in updated:
    tiles.update(tile_keys(sid))
required = {n for n in features if any(k in tiles for k in tile_keys(n))}
assert updated <= required
selected = []
for n,f in features.items():
    if n not in required:
        continue
    selected.append({'type':'Feature','properties':{'id':n},'geometry':f['geometry']})
    expected = new[n]['sha256'] if n in new else assets[n+'.tif']['digest'].removeprefix('sha256:')
    assert assets[n+'.tif']['digest'] == 'sha256:'+expected
    if 'digest' in f['properties']:
        assert expected == f['properties']['digest'], n
    else:
        assert n not in new and assets[n+'.tif']['state']=='uploaded', n
write_json('affected-bounds.geojson',{'type':'FeatureCollection','features':selected})
write_json('sources.json',{n+'.tif':{'size':assets[n+'.tif']['size'],'digest':assets[n+'.tif']['digest'],'url':assets[n+'.tif']['browser_download_url'],'local':n in new} for n in sorted(required)})
listings('retile-sheets.txt',(n+'.tif' for n in updated))
listings('required.txt',(n+'.tif' for n in required))
parent = {(k>>base_zoom,k & ((1<<base_zoom)-1)) for k in tiles}
with (job/'affected-base.xyz').open('w') as stream:
    for x,y in sorted(parent):
        print(base_zoom,x,y,file=stream)
levels = {base_zoom:len(parent)}
sibling_counts = {}
with (job/'unchanged-children.xyz').open('w') as stream:
    for z in range(base_zoom,0,-1):
        ancestors = {(x//2,y//2) for x,y in parent}
        siblings = {(x*2+i,y*2+j) for x,y in ancestors for i in (0,1) for j in (0,1)} - parent
        for x,y in sorted(siblings):
            print(z,x,y,file=stream)
        sibling_counts[z] = len(siblings)
        levels[z-1] = len(ancestors)
        parent = ancestors
summary=dict(new=len(new), restored=sorted(restored), neighboring_cogs=len(required-updated), required_cogs=len(required),base_zoom=base_zoom,levels=levels,unchanged_children=sibling_counts, neighbors_bytes=sum(assets[n+'.tif']['size'] for n in required-new.keys()), released_bounds_sha256=verification['bounds_sha256'])
write_json('plan.json',summary)
print(json.dumps(summary,indent=2),flush=True)
