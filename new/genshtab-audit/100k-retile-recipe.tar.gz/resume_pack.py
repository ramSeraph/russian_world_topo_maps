"""Resume validated shard packaging after interrupted transport or a terminated worker."""
import fcntl
import json
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path.cwd()
STATE = ROOT / 'pack'
STATE.mkdir(exist_ok=True)
LOG = ROOT / 'pack.log'
ALERT = STATE / 'needs-inspection.txt'
NETWORK_ERRORS = (
    'ConnectionError', 'TimeoutError', 'ReadTimeout', 'ConnectionResetError',
    'connection reset', 'IncompleteRead', 'Incomplete original', 'Network is unreachable',
    'Eight unsuccessful upload attempts', 'Max retries exceeded', 'HTTPError: 502',
    'HTTPError: 503', 'HTTPError: 504', 'RemoteDisconnected',
)


def worker_active():
    with (STATE / 'worker.lock').open('a') as stream:
        try:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return True
        return False


def prior_error():
    if not LOG.exists():
        return ''
    with LOG.open('rb') as stream:
        stream.seek(max(0, LOG.stat().st_size - 12000))
        tail = stream.read().decode(errors='replace')
    # A resumed run that later lost its process owns only its own log segment.
    tail = tail.rsplit('Starting resumed packing process', 1)[-1]
    if 'Traceback (most recent call last)' not in tail:
        return ''
    return tail.rsplit('Traceback (most recent call last)', 1)[-1]


def record_abrupt_exit():
    marker = STATE / 'unexplained-exits.json'
    checkpoint = {
        'groups': len(list((STATE / 'groups').glob('*.json'))),
        'patch_index': (STATE / 'patch-index.json').exists(),
    }
    previous = json.loads(marker.read_bytes()) if marker.is_file() else {}
    count = 1 + (previous['count'] if previous.get('checkpoint') == checkpoint else 0)
    temporary = marker.with_suffix('.tmp')
    temporary.write_text(json.dumps({'checkpoint': checkpoint, 'count': count}) + '\n')
    temporary.replace(marker)
    return count


def supervise():
    while not (STATE / 'package-done.tar.gz').is_file():
        if not (ROOT / 'patch-ready.json').is_file() or not (ROOT / 'old-dirs/cache-ready.json').is_file() or worker_active():
            time.sleep(45)
            continue
        time.sleep(30)
        if worker_active() or (STATE / 'package-done.tar.gz').is_file():
            continue
        if ALERT.is_file():
            time.sleep(60)
            continue
        error = prior_error()
        if error and not any(key in error for key in NETWORK_ERRORS):
            ALERT.write_text(error)
            continue
        if not error and record_abrupt_exit() > 3:
            ALERT.write_text('The packing process terminated without a Python error four times at the same checkpoint. Inspect the host before retrying.\n')
            continue
        reason = error.splitlines()[-1] if error else 'no completion or Python error'
        print('Resuming an interrupted packaging process:', reason, flush=True)
        time.sleep(120)
        if worker_active():
            continue
        with LOG.open('a') as stream:
            print('Starting resumed packing process', int(time.time()), file=stream, flush=True)
            subprocess.run([sys.executable, '-u', str(ROOT / 'pack100.py')], cwd=ROOT,
                           stdout=stream, stderr=subprocess.STDOUT)


if __name__ == '__main__':
    with (STATE / 'supervisor.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        supervise()
