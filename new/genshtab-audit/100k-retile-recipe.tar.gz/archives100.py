"""Lookup old PMTiles from their pinned release directory, with a local cache for renderer inputs."""
import argparse
import bisect
import fcntl
import hashlib
import json
import os
import sqlite3
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
import requests
from pmtiles.tile import deserialize_directory, deserialize_header, zxy_to_tileid
from pmtiles_mosaic.tiles_common import MissingTileError

def digest(path):
    with Path(path).open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()

def write_json(path,obj):
    tmp=path.with_suffix('.partial');tmp.write_text(json.dumps(obj,indent=2)+'\n');tmp.replace(path)

def records(root):
    all_assets={r['name']:r for r in json.loads((root/'baseline-pmtiles.json').read_bytes())}
    manifest=json.loads((root/'old-mosaic.json').read_bytes())
    assert all_assets['Soviet-GS-100k.mosaic.json']['digest']=='sha256:'+digest(root/'old-mosaic.json')
    names=sorted(manifest['slices'])
    assert set(names)=={n for n in all_assets if n.endswith('.pmtiles')} and len(names)==22
    return manifest,[all_assets[n] for n in names]

class Ranges:
    def __init__(self,asset):
        self.asset=asset;self.url=None;self.opened=0;self.session=requests.Session()
    def read(self,start,length):
        assert start>=0 and 0<length<=self.asset['size']-start
        for attempt in range(8):
            try:
                if not self.url or time.monotonic()-self.opened>2700:
                    r=self.session.get(self.asset['browser_download_url'],params={'rwt100k':f"{self.asset['id']}-{int(time.time())//300}"},allow_redirects=False,stream=True,timeout=(12,35))
                    with r:
                        assert r.is_redirect,(self.asset['name'],r.status_code)
                        self.url=r.headers['Location'];self.opened=time.monotonic()
                h={'Range':f'bytes={start}-{start+length-1}','Accept-Encoding':'identity'}
                with self.session.get(self.url,headers=h,timeout=(15,90),stream=True) as res:
                    if res.status_code!=206:raise ValueError((self.asset['name'],res.status_code,start,length))
                    assert res.headers['Content-Range']==f"bytes {start}-{start+length-1}/{self.asset['size']}"
                    data=res.content
                    assert len(data)==length
                    return data
            except (requests.RequestException,ValueError,AssertionError) as err:
                self.url=None
                if attempt==7:raise
                print('Range retry',self.asset['name'],start,length,attempt+1,type(err).__name__,flush=True)
                time.sleep(min(20,2**attempt))
    def close(self):self.session.close()

def walk_entries(buf):
    head=deserialize_header(buf[:127])
    def walk(start,length):
        for e in deserialize_directory(buf[start:start+length]):
            if e.run_length:yield e
            else:yield from walk(head['leaf_directory_offset']+e.offset,e.length)
    return head,walk(head['root_offset'],head['root_length'])

def obtain_prefix(item):
    asset,store=item
    out=store/(asset['name']+'.prefix')
    if out.is_file():
        head=deserialize_header(out.read_bytes()[:127])
        if out.stat().st_size==head['tile_data_offset']:return
    read=Ranges(asset)
    try:
        first=read.read(0,127);head=deserialize_header(first)
        assert 127<head['tile_data_offset']<60_000_000
        raw=first+read.read(127,head['tile_data_offset']-127)
        tmp=out.with_suffix('.tmp');tmp.write_bytes(raw);tmp.replace(out)
        print('Fetched directory',asset['name'],len(raw),flush=True)
    finally:read.close()

def build(root):
    manifest,assets=records(root)
    store=root/'old-dirs';store.mkdir(exist_ok=True)
    with (store/'build.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        final=store/'ready.json'; index=store/'index.npy'
        snap=digest(root/'baseline-pmtiles.json')
        if final.exists() and index.exists() and json.loads(final.read_bytes())['snapshot']==snap:return
        with ThreadPoolExecutor(5) as ex:list(ex.map(obtain_prefix,[(a,store) for a in assets]))
        maxz=manifest['header']['max_zoom'];n=(4**(maxz+1)-1)//3
        tmp=store/'index.partial.npy';idx=np.lib.format.open_memmap(tmp,mode='w+',dtype='uint64',shape=(n,))
        groups={};total=0
        for j,a in enumerate(assets,1):
            prefix=store/(a['name']+'.prefix');raw=prefix.read_bytes();head,entries=walk_entries(raw);count=0
            for e in entries:
                off=head['tile_data_offset']+e.offset
                assert 0<off<2**32 and 0<e.length<2**24 and off+e.length<=a['size']
                i=e.tile_id;end=i+e.run_length;assert 0<=i<end<=n
                if end==i+1:assert not idx[i]
                else:assert not np.any(idx[i:end])
                idx[i:end]=(j<<56)|(e.length<<32)|off;count+=e.run_length
            assert count==head['addressed_tiles_count'];total+=count
            groups[a['name']]={'count':count,'prefix_sha256':hashlib.sha256(raw).hexdigest(),'size':a['size']}
            print('Indexed',a['name'],count,flush=True)
        idx.flush();del idx;tmp.replace(index)
        write_json(final,{'snapshot':snap,'index_sha256':digest(index),'count':total,'parts':groups})
        print('Old lookup ready',total,flush=True)

class Old:
    def __init__(self,root):
        self.root=Path(root);self.manifest,self.assets=records(self.root);self.min_zoom=self.manifest['header']['min_zoom'];self.max_zoom=self.manifest['header']['max_zoom']
        self.store=self.root/'old-dirs'
        if not (self.store/'ready.json').is_file():build(self.root)
        self.index=np.load(self.store/'index.npy',mmap_mode='r')
        self.reset();self.proc=os.getpid()
    def reset(self):self.readers={};self.db=None
    def get_metadata(self):return dict(self.manifest['metadata'])
    def data_at(self,tid):
        ptr=int(self.index[tid])
        if not ptr:return None
        if self.proc!=os.getpid():self.reset();self.proc=os.getpid()
        if self.db is None and (self.store/'cache.sqlite').is_file():
            self.db=sqlite3.connect(f'file:{self.store}/cache.sqlite?mode=ro',uri=True,timeout=75)
        if self.db:
            row=self.db.execute('select payload from blobs where p=?',(ptr,)).fetchone()
            if row:return row[0]
        g=(ptr>>56)-1
        reader=self.readers.get(g)
        if reader is None:reader=self.readers[g]=Ranges(self.assets[g])
        return reader.read(ptr&0xffffffff,(ptr>>32)&0xffffff)
    def get_tile_data(self,t):
        data=self.data_at(zxy_to_tileid(t.z,t.x,t.y))
        if data is None:raise MissingTileError()
        return data
    def cleanup(self):
        if self.db:self.db.close()
        for r in self.readers.values():r.close()
        self.reset()

def previous(root):return Old(root)

if __name__=='__main__':
    build(Path.cwd())
