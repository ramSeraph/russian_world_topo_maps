"""Safely replace the two release aliases after the dated PMTiles are verified."""
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
import requests
P=Path(__file__).parent
REPO='ramSeraph/russian_world_topo_maps';TAG='100k-gs-pmtiles';API='repos/'+REPO+'/releases'
CANON='Soviet-GS-100k.mosaic.json';BOUNDS='bounds.geojson'
SHAPE=P/'released-georef-bounds.geojson'
SHAPE_SHA='ed3ef0258ac7cc2be486571f8398e83af0b01eb3eac56f88b6596a0371338ea6'
def gh(*args):return subprocess.check_output(['gh',*args],text=True)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def dump(p,v):
    t=p.with_suffix('.tmp');t.write_text(json.dumps(v,indent=2)+'\n');t.replace(p)
def load(p):return json.loads(p.read_bytes())
def gh_assets(tag=TAG):
    rel=json.loads(gh('api',API+'/tags/'+tag))
    return {r['name']:r for r in rel['assets']}
def exact(a,hs,size):return a and a['state']=='uploaded' and a['digest']=='sha256:'+hs and a['size']==size
def rename(a,n):gh('api','-X','PATCH',API+'/assets/'+str(a['id']),'-f','name='+n,'--silent')
def get(a):
    req=requests.get(a['browser_download_url'],params={'asset':a['id']},timeout=(15,90))
    req.raise_for_status();return req.content
def check_header(arg):
    a,s=arg;url=a['browser_download_url'];h={'Range':'bytes=0-126','Accept-Encoding':'identity'}
    for i in range(5):
        try:
            with requests.get(url,headers=h,params={'pm100':a['id']},stream=True,timeout=(10,45)) as r:
                r.raise_for_status();b=next(r.iter_content(127))
                assert r.status_code==206 and r.headers['Content-Range']==f'bytes 0-126/{a["size"]}',a['name']
                assert len(b)==127 and b[:8]==b'PMTiles\x03' and b[99]==4 and [b[100],b[101]]==[s['header']['min_zoom'],s['header']['max_zoom']],a['name']
            return {'name':a['name'],'id':a['id'],'bytes':a['size'],'header_sha256':sha(b),'minzoom':b[100],'maxzoom':b[101]}
        except (OSError,AssertionError,requests.RequestException):
            if i==4:raise
            time.sleep(2**i)
def stage(name,path,a,old):
    hs=sha(path.read_bytes());size=path.stat().st_size
    previous=name+'.'+old['digest'][7:19]+'.previous';temp=name+'.'+hs[:12]+'.staged'
    if exact(a.get(name),hs,size):return
    held=a.get(name) or a.get(previous)
    assert held and held['id']==old['id'] and held['digest']==old['digest'],('baseline differs',name)
    if temp not in a:
        link=P/'staged'/temp;link.parent.mkdir(exist_ok=True)
        if not link.exists():os.link(path,link)
        assert sha(link.read_bytes())==hs
        gh('release','upload',TAG,str(link),'--repo',REPO)
    staged=gh_assets()[temp]
    assert exact(staged,hs,size) and sha(get(staged))==hs,(name,'staged')
def swap(name,path,old):
    hs=sha(path.read_bytes());size=path.stat().st_size;prev=name+'.'+old['digest'][7:19]+'.previous';temp=name+'.'+hs[:12]+'.staged'
    current=gh_assets()
    if exact(current.get(name),hs,size):return
    assert exact(current.get(temp),hs,size),(name,'staged bytes missing')
    if name in current:
        assert current[name]['id']==old['id'] and current[name]['digest']==old['digest'] and prev not in current,name
        rename(current[name],prev)
    else:assert current[prev]['id']==old['id'] and current[prev]['digest']==old['digest']
    try:rename(current[temp],name)
    except Exception:
        current=gh_assets()
        if name not in current:rename(current[prev],name)
        raise
    assert exact(gh_assets().get(name),hs,size)
def main():
    marked=load(P/'dated-assets-published.json')
    old={a['name']:a for a in load(P/'baseline-release.json')['assets']}
    assert marked['canonical']==CANON and marked['tag']==TAG and marked['baseline_mosaic_sha256']==old[CANON]['digest'][7:]
    d=marked['descriptor'];names=marked['parts'];state=gh_assets()
    f=P/d['name'];canon=P/CANON;raw=f.read_bytes()
    assert d['name']!=CANON and raw==canon.read_bytes() and len(raw)==d['size'] and sha(raw)==d['sha256']
    a=state[d['name']]
    assert exact(a,d['sha256'],d['size']) and get(a)==raw and a['id']==d['id']
    m=json.loads(raw);h=m['header'];assert set(m['slices'])==set(names) and (h['min_zoom'],h['max_zoom'],h['tile_type'])==(0,13,4)
    attr=m['metadata']['attribution'].lower();assert all(v in attr for v in ['vlasenko','mapstor','genshtab-100k-50k-europe-asia','satmaps.info','redatlasbook.com','permission','non-commercial'])
    assert h['min_lon_e7']==-1800000000 and h['max_lon_e7']==1800000000
    for n,r in names.items():
        assert n not in old and exact(state.get(n),r['sha256'],r['size']) and state[n]['id']==r['id'] and state[n]['browser_download_url']==r['url'],n
    assert sha(SHAPE.read_bytes())==SHAPE_SHA and len(load(SHAPE)['features'])==15639
    hist=gh_assets('100k-gs-georef')[BOUNDS];assert exact(hist,SHAPE_SHA,SHAPE.stat().st_size) and sha(get(hist))==SHAPE_SHA
    with ThreadPoolExecutor(5) as pool:headers=list(pool.map(check_header,[(state[n],m['slices'][n]) for n in sorted(names)]))
    dump(P/'public-part-headers.json',headers)
    expected=load(P/'independent-expected.json');points=load(P/'probe-points.json')
    assert expected.keys()==points.keys()
    full=load(P/'pack-verification.json')
    assert full['references']['patch-ready.json']==marked['patch_receipt_sha256'] and full['references']['old-mosaic.json']==marked['baseline_mosaic_sha256']
    assert full['stats']['old']==3214412 and full['stats']['output_tiles']==marked['output_tiles']==marked['patch_tiles']+marked['untouched_tiles']
    assert full['restorations']==3 and full['independent_points']==len(expected)==2732
    assert full['component_centres']==len(load(P/'centres.json'))==2692 and len(load(P/'restored-centres.json'))==3
    assert full['output_levels']==marked['output_levels'] and full['old_header']==load(P/'baseline.mosaic.json')['header'] and full['header']==h
    assert marked['output_tiles']>0 and marked['untouched_tiles']>0 and marked['patch_tiles']>0
    # Stage both replacements first, then switch the mosaic before updating its published footprint index.
    for n,path in [(CANON,canon),(BOUNDS,SHAPE)]:stage(n,path,gh_assets(),old[n])
    for n,path in [(CANON,canon),(BOUNDS,SHAPE)]:swap(n,path,old[n])
    state=gh_assets();verified={}
    for n,path in [(CANON,canon),(BOUNDS,SHAPE)]:
        r=state[n];hs=sha(path.read_bytes());assert sha(get(r))==hs and exact(r,hs,path.stat().st_size)
        backup=n+'.'+old[n]['digest'][7:19]+'.previous'
        assert state[backup]['id']==old[n]['id'] and state[backup]['digest']==old[n]['digest']
        verified[n]={'id':r['id'],'url':r['browser_download_url'],'size':r['size'],'sha256':hs,'prior_asset':backup}
    result={'tag':TAG,'dated_descriptor':d['name'],'parts':len(headers),'verified_part_headers':len(headers),'assets':verified,'bounds_features':15639,'date_manifest_sha256':sha((P/'dated-assets-published.json').read_bytes()),'public_route':'https://indianopenmaps.com/world/topo/russian/100k/gs/'}
    dump(P/'route-receipt.json',result);print('Verified public stable descriptor, bounds, preserved prior metadata and',len(headers),'dated part headers.',flush=True)
if __name__=='__main__':main()
